# GIANT XT-BIOS v0.5.1 (clean-room hobbyproject)

Minimale 8 KB BIOS voor een IBM PC/XT-compatibele machine (8088, F000:E000-FFFF).

## Bouwen
GNU binutils (`as`, `ld`, `objcopy`) en Python 3; op Windows via WSL:

    make            # -> xtbios.bin (8192 bytes, checksum klopt)
    make listing    # -> xtbios.lst (disassembly)

Het font staat als ASCII-art in `font8x8.txt` (eigen ontwerp); `mkfont.py`
maakt er `font8x8.inc` van. `python3 mkfont.py preview.png` geeft een preview
(vereist Pillow). Zie `docs/font8x8.png`.

## Testen
`pip install unicorn pillow`, dan `make -C test test` (alle scenario's) of
`make -C test gfxtest` (alleen grafisch; PNG's in `test/shots/`) of
`make -C test pagetest` (videopagina's, zoals CheckIt) of
`make -C test v04test` (harde schijf via nep-option-ROM, 512 KB, defect RAM,
ROM-checksumfout, geen video, warme start, AH=13h).
Alle testdiskettes starten na afloop met een toets opnieuw op.
Zie `docs/grafisch-test.png` voor het verwachte resultaat.

## Status
| Onderdeel | Versie |
|---|---|
| POST, POST-codes poort 80h, option-ROMs | v0.1 |
| INT 10h tekst (CGA/MDA), INT 13h diskette, INT 19h | v0.1 |
| INT 08h, 0Eh, 11h, 12h, 1Ah | v0.1 |
| Toetsenbord (INT 09h/16h) incl. Ctrl-Alt-Del, Ctrl-Break, Pause | v0.2 |
| INT 14h serieel, INT 17h printer, INT 05h print screen, formatteren | v0.2 |
| Eigen 8x8-font op F000:FA6E (tekens 00h-7Fh) | v0.3 |
| INT 10h grafisch (modi 4/5/6): AH=0Ch/0Dh pixels, 08h/09h/0Ah/0Eh tekst, | v0.3 |
| 06h/07h scrollen, 0Bh palet, 04h lichtpen (geeft "geen") | v0.3 |
| Tekens 80h-FFh in grafische modi via INT 1Fh (bv. DOS GRAFTABL) | v0.3 |
| Fix: INT 10h AH=08/09/0Ah schrijven/lezen op pagina BH (CheckIt-paginatest) | v0.3.1 |
| INT 19h: na A: ook C: (80h) als een option-ROM harde schijven meldt (0040:0075) | v0.4 |
| Snelle warme start (Ctrl-Alt-Del): geen RAM-test, "(warm start)" | v0.4 |
| Piepcodes bij POST-fouten en zonder videokaart (zie onder) | v0.4 |
| 8087-detectie (equipment bit 1), CPU-herkenning 8088 / NEC V20 | v0.4 |
| Configuratieoverzicht: CPU, FPU, diskettestations, harde schijven, COM, LPT | v0.4 |
| Zichtbare geheugentest, met "RAM error at SSSS:OOOO" bij een fout in een blok | v0.4 |
| INT 10h AH=13h (string schrijven, modi 0-3) | v0.4 |
| Fix: warme start wist geheugen en BDA weer (XT-IDE bootte niet na Ctrl-Alt-Del) | v0.4.1 |
| Fix: toetsenbordtest slaat bytes vóór AAh over (86Box: "Keyboard error" na Ctrl-Alt-Del) | v0.4.1 |
| Naam "IMACOM XT-BIOS"; naam en versie staan op één plek (macro BIOS_NAME bovenin xtbios.S) | v0.4.2 |
| INT 18h start BBC BASIC uit de BASIC-socket (F600:0000, handtekening "BBCROM") | v0.5 |
| POST: ~1,5 s "Press B for BBC BASIC" (alleen als die ROM aanwezig is) | v0.5 |
| Naam "GIANT XT-BIOS" | v0.5.1 |

## Piepcodes (v0.4)
| Patroon | Betekenis |
|---|---|
| 1 korte piep | POST geslaagd |
| 1 lange, 2 korte | geen videokaart gevonden (de BIOS start wel door) |
| 1 piep, herhalend | CPU-fout (POST-code E1) |
| 2 piepjes, herhalend | ROM-checksum fout (E2) |
| 3 piepjes, herhalend | fout in eerste 16 KB RAM (E3) |

## Bekende beperkingen
* INT 10h AH=13h: regelomloop en scrollen gelden voor de actieve pagina.
* Neemt een option-ROM (zoals XT-IDE) zelf INT 19h over, dan bepaalt die ROM de bootvolgorde.
* De 8087-detectie is in de simulator alleen getest *met* FPU; "none" nog op echte hardware/86Box controleren.

## POST-codes (poort 80h)
01 start · 02 CPU · 03 ROM-checksum · 04 timers/DMA · 05 eerste 16 KB ·
06 vectoren/BDA/8087/poorten · 07 video + video-ROMs · 08 geheugen geteld ·
09 overige option-ROMs · 0A toetsenbord · 0B boot. Fout: E1 CPU, E2 ROM-checksum, E3 RAM.

## BBC BASIC-ROM (v0.5, map `bbcrom/`)
BBC BASIC (86) Plus van R.T. Russell als ROM BASIC in de 27256-socket.
Zet `BBCBASIC.EXE` in `bbcrom/` en draai `make -C bbcrom`:
* `bbcrom.bin` - voor de OneROM/EPROM (27256), al "gedraaid" voor de XPC
  (chip-offset 6000h verschijnt op F600:0000, zie `mkrom.py`)
* `bbcrom_log.bin` - logische volgorde, voor de simulator

Inhoud: lader (pakt het LZSS-gecomprimeerde programma uit naar 0000:0800,
bouwt een PSP) en een mini-DOS (INT 20h/21h/29h) met de console- en
systeemfuncties die BBC BASIC gebruikt. Er is geen bestandssysteem:
LOAD/SAVE/*CAT geven een nette DOS-fout ("File not found", "Access denied").
`*QUIT` (of einde programma) -> melding, toets, opnieuw opstarten.
Het EXE-bestand zelf zit niet in de bron; het blijft het werk van R.T. Russell.
