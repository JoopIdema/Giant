#=============================================================================
#  bbcrom.S  -  BBC BASIC (86) als ROM BASIC voor de GIANT XT-BIOS
#
#  32 KB ROM, logisch op F600:0000-FDFF:000F (de BASIC-socket, 27256).
#  Start via INT 18h (F600:0000), zoals ROM BASIC op een IBM PC/XT.
#
#  Inhoud:  - lader: kopieert BBCBASIC.EXE (31430 bytes, zonder relocaties)
#             naar RAM, bouwt een PSP en start het programma
#           - mini-DOS: precies de INT 21h-functies die BBC BASIC gebruikt;
#             console via BIOS, geen bestandssysteem (nette DOS-foutcodes)
#
#  Het EXE-image zelf is van R.T. Russell en zit NIET in de bron; het wordt
#  bij het bouwen uit BBCBASIC.EXE gehaald (zie Makefile / mkrom.py).
#=============================================================================

        .intel_syntax noprefix
        .code16
        .arch   i8086
        .text

        .equ    PSPSEG,   0x0070        # PSP op 0000:0700
        .equ    IMGSEG,   0x0080        # programma op 0000:0800
        .equ    VARSEG,   0x0060        # mini-DOS-variabelen op 0000:0600
        .include "image.inc"            # IMGSIZE, EXE_SS, EXE_SP, ... (mkimage.py)

        # variabelen (segment VARSEG)
        .equ    V_PEND,   0x00          # uitgestelde scancode (uitgebreide toets)
        .equ    V_DTA,    0x02          # dword
        .equ    V_DATE,   0x06          # jaar (word), maand, dag
        .equ    V_LPOS,   0x0A          # leespositie regelbuffer (handle 0)
        .equ    V_LLEN,   0x0C          # lengte regelbuffer
        .equ    V_ENV,    0x10          # lege omgeving (2 nullen), paragraaf 0x61
        .equ    V_LBUF,   0x80          # regelbuffer, 128 bytes

#=============================================================================
start:  jmp     short entry
        .ascii  "BBCROM"                # handtekening (BIOS kijkt naar F600:0002)
        .ascii  " BBC BASIC (86) ROM loader for GIANT XT-BIOS\0"

entry:  cli
        mov     ax, 0x0030
        mov     ss, ax
        mov     sp, 0x0100
        sti
        cld
        mov     ax, 0x0003              # schoon tekstscherm
        int     0x10

        # 0600-FFFF wissen (variabelen, PSP, programma en zijn data)
        xor     ax, ax
        mov     es, ax
        mov     di, 0x0600
        mov     cx, (0x10000 - 0x0600) / 2
        rep     stosw

        # programma uitpakken (LZSS, zie mkimage.py)
        mov     ax, cs
        mov     ds, ax
        mov     si, offset image
        mov     ax, IMGSEG
        mov     es, ax
        xor     di, di
        mov     dx, IMGSIZE
3:      lodsb                           # stuurbyte
        mov     bh, al
        mov     bl, 8
4:      cmp     di, dx
        jae     7f
        shr     bh, 1
        jnc     5f
        movsb                           # letterlijk
        jmp     6f
5:      lodsw                           # verwijzing
        push    si
        push    ds
        mov     cl, 4
        mov     ch, ah
        shr     ch, cl
        and     ax, 0x0FFF
        inc     ax
        mov     si, di
        sub     si, ax
        mov     cl, ch
        xor     ch, ch
        add     cx, 3
        push    es
        pop     ds
        rep     movsb
        pop     ds
        pop     si
6:      dec     bl
        jnz     4b
        jmp     3b
7:

        # variabelen
        mov     ax, VARSEG
        mov     es, ax
        mov     word ptr es:[V_DTA], 0x0080
        mov     word ptr es:[V_DTA+2], PSPSEG
        mov     word ptr es:[V_DATE], 2026
        mov     word ptr es:[V_DATE+2], 0x0101  # 1 januari

        # PSP
        mov     ax, PSPSEG
        mov     es, ax
        mov     word ptr es:[0x00], 0x20CD      # INT 20h
        int     0x12                            # geheugen in KB
        mov     cl, 6
        shl     ax, cl
        mov     es:[0x02], ax                   # eerste segment na het geheugen
        mov     word ptr es:[0x0A], offset do_exit
        mov     es:[0x0C], cs
        mov     word ptr es:[0x16], PSPSEG      # ouder = zichzelf
        mov     word ptr es:[0x2C], VARSEG + 1  # omgeving (leeg)
        mov     word ptr es:[0x50], 0x21CD      # INT 21h + RETF
        mov     byte ptr es:[0x52], 0xCB
        mov     byte ptr es:[0x5D], ' '         # lege FCB-namen
        mov     byte ptr es:[0x6D], ' '
        mov     byte ptr es:[0x81], 0x0D        # lege opdrachtregel

        # interruptvectoren
        xor     ax, ax
        mov     es, ax
        mov     si, offset vec_list
1:      mov     bl, cs:[si]
        or      bl, bl
        jz      2f
        xor     bh, bh
        shl     bx, 1
        shl     bx, 1
        mov     ax, cs:[si+1]
        mov     es:[bx], ax
        mov     es:[bx+2], cs
        add     si, 3
        jmp     1b

        # starten
2:      cli
        mov     ax, IMGSEG + EXE_SS
        mov     ss, ax
        mov     sp, EXE_SP
        sti
        mov     ax, PSPSEG
        mov     ds, ax
        mov     es, ax
        xor     ax, ax
        xor     bx, bx
        mov     cx, 0x00FF
        mov     dx, PSPSEG
        .byte   0xEA                    # jmp far naar het EXE-startpunt
        .word   EXE_IP, IMGSEG + EXE_CS

vec_list:
        .byte   0x20
        .word   int20
        .byte   0x21
        .word   int21
        .byte   0x22
        .word   do_exit
        .byte   0x23
        .word   int23
        .byte   0x24
        .word   int24
        .byte   0x27
        .word   int20
        .byte   0x29
        .word   int29
        .byte   0x28
        .word   iret_x
        .byte   0x2F
        .word   iret_x
        .byte   0

#=============================================================================
#  INT 21h
#=============================================================================
int21:  sti
        cld
        push    si
        mov     si, offset fn_table
1:      cmp     byte ptr cs:[si], 0xFF
        je      2f
        cmp     ah, cs:[si]
        je      3f
        add     si, 3
        jmp     1b
3:      mov     si, cs:[si+1]           # handleradres op de plaats van SI
        push    bp
        mov     bp, sp
        xchg    si, [bp+2]
        pop     bp
        ret
2:      pop     si
        push    ax
        mov     al, ah
        out     0xE3, al                # simulator: onbekende functie loggen
        pop     ax
        mov     ax, 1                   # "ongeldige functie"
        jmp     err_exit

fn_table:
        .byte 0x00
        .word do_exit
        .byte 0x01
        .word f01
        .byte 0x02
        .word f02
        .byte 0x05
        .word f05
        .byte 0x06
        .word f06
        .byte 0x07
        .word f07
        .byte 0x08
        .word f07
        .byte 0x09
        .word f09
        .byte 0x0A
        .word f0a
        .byte 0x0B
        .word f0b
        .byte 0x0C
        .word f0c
        .byte 0x0D
        .word ok_exit
        .byte 0x0E
        .word f0e
        .byte 0x19
        .word f19
        .byte 0x1A
        .word f1a
        .byte 0x25
        .word f25
        .byte 0x2A
        .word f2a
        .byte 0x2B
        .word f2b
        .byte 0x2C
        .word f2c
        .byte 0x2D
        .word f2d
        .byte 0x2F
        .word f2f
        .byte 0x30
        .word f30
        .byte 0x33
        .word f33
        .byte 0x35
        .word f35
        .byte 0x37
        .word f37
        .byte 0x39
        .word err_path
        .byte 0x3A
        .word err_path
        .byte 0x3B
        .word err_path
        .byte 0x3C
        .word err_access
        .byte 0x3D
        .word err_nofile
        .byte 0x3E
        .word f3e
        .byte 0x3F
        .word f3f
        .byte 0x40
        .word f40
        .byte 0x41
        .word err_nofile
        .byte 0x42
        .word err_handle
        .byte 0x44
        .word f44
        .byte 0x47
        .word f47
        .byte 0x48
        .word f48
        .byte 0x49
        .word ok_exit
        .byte 0x4A
        .word f4a
        .byte 0x4B
        .word err_nofile
        .byte 0x4C
        .word do_exit
        .byte 0x4E
        .word err_nomore
        .byte 0x4F
        .word err_nomore
        .byte 0x56
        .word err_nofile
        .byte 0xFF

#--- gemeenschappelijke uitgangen ---------------------------------------------
err_nofile:
        mov     ax, 2
        jmp     err_exit
err_path:
        mov     ax, 3
        jmp     err_exit
err_access:
        mov     ax, 5
        jmp     err_exit
err_handle:
        mov     ax, 6
        jmp     err_exit
err_nomore:
        mov     ax, 18
err_exit:
        stc
        retf    2
ok_exit:
        clc
        retf    2
iret_x: iret

#--- console -------------------------------------------------------------------
# con_out: AL naar het scherm (teletype op de actieve pagina)
con_out:
        push    ax
        push    bx
        push    ax
        mov     ah, 0x0F
        int     0x10                    # BH = actieve pagina
        pop     ax
        mov     ah, 0x0E
        mov     bl, 7
        int     0x10
        pop     bx
        pop     ax
        ret

# key_get: wacht op toets -> AL (uitgebreide toets: eerst 0, daarna scancode)
key_get:
        push    ds
        push    bx
        mov     bx, VARSEG
        mov     ds, bx
        xor     al, al
        xchg    al, ds:[V_PEND]
        or      al, al
        jnz     2f
        xor     ah, ah
        int     0x16
        or      al, al
        jz      1f
        cmp     al, 0xE0
        jne     2f
        or      ah, ah
        jz      2f
1:      mov     ds:[V_PEND], ah         # 0 teruggeven, scancode bewaren
        xor     al, al
2:      pop     bx
        pop     ds
        ret

# key_ready: ZF=0 als er een teken klaarstaat
key_ready:
        push    ds
        push    ax
        mov     ax, VARSEG
        mov     ds, ax
        cmp     byte ptr ds:[V_PEND], 0
        jne     1f
        mov     ah, 1
        int     0x16
1:      pop     ax
        pop     ds
        ret

int29:  call    con_out
        iret

f01:    call    key_get                 # lezen met echo
        call    con_out
        jmp     ok_exit
f02:    push    ax                      # teken DL naar scherm
        mov     al, dl
        call    con_out
        pop     ax
        mov     al, dl
        jmp     ok_exit
f05:    push    ax                      # teken DL naar printer
        push    dx
        mov     al, dl
        xor     ah, ah
        xor     dx, dx
        int     0x17
        pop     dx
        pop     ax
        jmp     ok_exit
f06:    cmp     dl, 0xFF                # directe console-I/O
        je      1f
        mov     al, dl
        call    con_out
        jmp     ok_exit
1:      call    key_ready
        jz      2f
        call    key_get
        cmp     al, 0xFF                # ZF=0 forceren (AL kan 0 zijn)
        or      dl, dl                  # DL=FF -> ZF=0
        clc
        retf    2
2:      xor     al, al                  # geen teken: ZF=1
        clc
        retf    2
f07:    call    key_get                 # lezen zonder echo (07 en 08)
        jmp     ok_exit
f09:    push    ax                      # string DS:DX tot '$'
        push    si
        mov     si, dx
1:      lodsb
        cmp     al, '$'
        je      2f
        call    con_out
        jmp     1b
2:      pop     si
        pop     ax
        mov     al, '$'
        jmp     ok_exit
f0a:    push    ax                      # gebufferde invoer DS:DX
        push    bx
        push    cx
        push    di
        mov     di, dx
        mov     cl, [di]
        dec     cl                      # ruimte voor CR
        call    read_line_ds
        pop     di
        pop     cx
        pop     bx
        pop     ax
        jmp     ok_exit
f0b:    call    key_ready               # invoerstatus
        mov     al, 0
        jz      1f
        dec     al
1:      jmp     ok_exit
f0c:    push    ax                      # buffer leegmaken, dan functie AL
1:      call    key_ready
        jz      2f
        call    key_get
        jmp     1b
2:      pop     ax
        mov     ah, al
        cmp     ah, 0x01
        je      f01
        cmp     ah, 0x06
        je      f06
        cmp     ah, 0x07
        je      f07
        cmp     ah, 0x08
        je      f07
        cmp     ah, 0x0A
        je      f0a
        xor     al, al
        jmp     ok_exit

# read_line_ds: regel invoeren in DS:DI (formaat van functie 0Ah), CL = max
read_line_ds:
        xor     ch, ch                  # CH = aantal
1:      call    key_get
        or      al, al
        jnz     2f
        call    key_get                 # uitgebreide toets negeren
        jmp     1b
2:      cmp     al, 0x0D
        je      5f
        cmp     al, 0x08
        je      3f
        cmp     ch, cl
        jae     1b                      # vol
        mov     bl, ch
        xor     bh, bh
        mov     [di+bx+2], al
        inc     ch
        call    con_out
        jmp     1b
3:      or      ch, ch
        jz      1b
        dec     ch
        mov     al, 0x08
        call    con_out
        mov     al, ' '
        call    con_out
        mov     al, 0x08
        call    con_out
        jmp     1b
5:      mov     bl, ch
        xor     bh, bh
        mov     byte ptr [di+bx+2], 0x0D
        mov     [di+1], ch
        call    con_out                 # CR
        ret

#--- schijf, datum/tijd, vectoren, diversen --------------------------------------
f0e:    mov     al, 1                   # station kiezen: 1 station
        jmp     ok_exit
f19:    xor     al, al                  # huidig station = A:
        jmp     ok_exit
f1a:    push    ds                      # DTA instellen
        push    ax
        mov     ax, ds
        push    ax
        mov     ax, VARSEG
        mov     ds, ax
        pop     ax
        mov     ds:[V_DTA+2], ax
        mov     ds:[V_DTA], dx
        pop     ax
        pop     ds
        jmp     ok_exit
f2f:    push    ds                      # DTA opvragen -> ES:BX
        mov     bx, VARSEG
        mov     ds, bx
        les     bx, ds:[V_DTA]
        pop     ds
        jmp     ok_exit
f25:    push    es                      # vector AL := DS:DX
        push    bx
        xor     bx, bx
        mov     es, bx
        mov     bl, al
        shl     bx, 1
        shl     bx, 1
        cli
        mov     es:[bx], dx
        mov     es:[bx+2], ds
        sti
        pop     bx
        pop     es
        jmp     ok_exit
f35:    push    ds                      # vector AL -> ES:BX
        xor     bx, bx
        mov     ds, bx
        mov     bl, al
        shl     bx, 1
        shl     bx, 1
        les     bx, [bx]
        pop     ds
        jmp     ok_exit
f2a:    push    ds                      # datum -> CX jaar, DH maand, DL dag
        mov     cx, VARSEG
        mov     ds, cx
        mov     cx, ds:[V_DATE]
        mov     dx, ds:[V_DATE+2]
        pop     ds
        xor     al, al                  # (weekdag niet bijgehouden)
        jmp     ok_exit
f2b:    push    ds                      # datum zetten
        push    ax
        mov     ax, VARSEG
        mov     ds, ax
        mov     ds:[V_DATE], cx
        mov     ds:[V_DATE+2], dx
        pop     ax
        pop     ds
        xor     al, al
        jmp     ok_exit
f2c:    push    ax                      # tijd uit de BIOS-tikken
        push    bx
        xor     ah, ah
        int     0x1A                    # CX:DX = tikken sinds middernacht
        xor     bx, bx                  # BX = uren
1:      cmp     cx, 1                   # 1 uur = 65543 tikken (0x10007)
        jb      2f
        ja      3f
        cmp     dx, 7
        jb      2f
3:      sub     dx, 7
        sbb     cx, 1
        inc     bx
        jmp     1b
2:      mov     ax, dx                  # rest < 65543: seconden = rest*10/182
        mov     cx, 10
        mul     cx
        mov     cx, 182
        div     cx                      # AX = seconden, DX = rest
        push    ax
        mov     ax, dx
        mov     cl, 100
        mul     cl
        mov     cl, 182
        div     cl                      # AL = honderdsten
        mov     ch, al
        pop     ax
        mov     cl, 60
        div     cl                      # AL = minuten, AH = seconden
        mov     dl, ch
        mov     dh, ah
        mov     cl, al
        mov     ch, bl
        pop     bx
        pop     ax
        xor     al, al
        jmp     ok_exit
f2d:    push    ax                      # tijd zetten: CH:CL:DH.DL
        push    bx
        push    cx
        push    dx
        mov     al, ch                  # seconden = ((u*60)+m)*60+s
        mov     ah, 60
        mul     ah
        xor     ch, ch
        add     ax, cx
        mov     bx, 60
        mul     bx                      # DX:AX
        mov     cl, dh
        xor     ch, ch
        add     ax, cx
        adc     dx, 0
        # tikken = seconden * 182 / 10
        mov     cx, ax
        mov     bx, dx
        mov     ax, bx
        mov     si, 182
        mul     si
        push    ax
        mov     ax, cx
        mul     si
        pop     cx
        add     dx, cx                  # DX:AX = seconden*182
        mov     cx, 10
        mov     bx, ax
        mov     ax, dx
        xor     dx, dx
        div     cx
        push    ax
        mov     ax, bx
        div     cx
        pop     cx                      # CX:AX = tikken
        mov     dx, ax
        mov     ah, 1
        int     0x1A
        pop     dx
        pop     cx
        pop     bx
        pop     ax
        xor     al, al
        jmp     ok_exit
f30:    mov     ax, 0x1E03              # DOS 3.30
        xor     bx, bx
        xor     cx, cx
        jmp     ok_exit
f33:    xor     dl, dl                  # Ctrl-Break-controle: uit
        jmp     ok_exit
f37:    mov     dl, '/'                 # schakelteken
        xor     al, al
        jmp     ok_exit
f47:    mov     byte ptr [si], 0        # huidige map: root
        jmp     ok_exit

#--- handles ----------------------------------------------------------------------
f3e:    cmp     bx, 4                   # sluiten: alleen standaardhandles
        ja      err_handle
        jmp     ok_exit
f40:    cmp     bx, 4                   # schrijven DS:DX, CX bytes
        ja      err_handle
        cmp     bx, 3
        je      err_handle
        push    cx
        push    si
        mov     si, dx
        jcxz    3f
1:      lodsb
        cmp     bx, 4
        je      2f
        call    con_out
        loop    1b
        jmp     3f
2:      push    dx
        xor     ah, ah
        xor     dx, dx
        int     0x17
        pop     dx
        loop    1b
3:      pop     si
        pop     ax                      # AX = aantal geschreven
        jmp     ok_exit
f3f:    or      bx, bx                  # lezen: alleen handle 0 (toetsenbord)
        jnz     err_handle
        push    es
        push    si
        push    di
        push    cx
        push    ds
        pop     es
        mov     di, dx                  # ES:DI = doel
        mov     si, VARSEG
        mov     ds, si
        mov     si, ds:[V_LPOS]
        cmp     si, ds:[V_LLEN]
        jb      2f
        push    di                      # nieuwe regel invoeren
        mov     di, V_LBUF - 2
        mov     cl, 125
        call    read_line_ds
        mov     al, 0x0A
        call    con_out
        mov     bl, ds:[V_LBUF-1]
        xor     bh, bh
        mov     word ptr ds:[V_LBUF+bx], 0x0A0D
        add     bx, 2
        mov     ds:[V_LLEN], bx
        mov     word ptr ds:[V_LPOS], 0
        xor     si, si
        pop     di
2:      pop     cx
        xor     ax, ax
3:      jcxz    4f
        cmp     si, ds:[V_LLEN]
        jae     4f
        mov     bl, ds:[V_LBUF+si]
        mov     es:[di], bl
        inc     si
        inc     di
        inc     ax
        dec     cx
        jmp     3b
4:      mov     ds:[V_LPOS], si
        push    es
        pop     ds
        pop     di
        pop     si
        pop     es
        jmp     ok_exit
f44:    cmp     al, 0x00                # IOCTL
        jne     1f
        mov     dx, 0x80D3              # apparaat, console
        cmp     bx, 4
        jne     ok_exit
        mov     dx, 0x80C0
        jmp     ok_exit
1:      cmp     al, 0x06                # invoerstatus
        jne     2f
        call    key_ready
        mov     al, 0
        jz      ok_exit
        dec     al
        jmp     ok_exit
2:      cmp     al, 0x07                # uitvoerstatus
        jne     3f
        mov     al, 0xFF
        jmp     ok_exit
3:      cmp     al, 0x01
        je      ok_exit
        mov     ax, 1
        jmp     err_exit

#--- geheugen -------------------------------------------------------------------
f48:    push    es                      # toewijzen: niet ondersteund
        mov     bx, PSPSEG
        mov     es, bx
        xor     bx, bx
        pop     es
        mov     ax, 8                   # onvoldoende geheugen, BX = 0
        jmp     err_exit
f4a:    push    ax                      # ES = blok (PSP), BX = gewenste grootte
        push    dx
        push    ds
        mov     ax, PSPSEG
        mov     ds, ax
        mov     ax, ds:[0x02]           # einde geheugen
        sub     ax, PSPSEG              # beschikbaar
        pop     ds
        pop     dx
        cmp     bx, ax
        ja      1f
        pop     ax
        jmp     ok_exit
1:      mov     bx, ax
        pop     ax
        mov     ax, 8
        jmp     err_exit

#--- einde programma -------------------------------------------------------------
int20:
do_exit:
        cli
        mov     ax, 0x0030
        mov     ss, ax
        mov     sp, 0x0100
        sti
        push    cs
        pop     ds
        mov     si, offset msg_exit
1:      lodsb
        or      al, al
        jz      2f
        call    con_out
        jmp     1b
2:      xor     ah, ah                  # toets, dan opnieuw opstarten
        int     0x16
        int     0x19
msg_exit:
        .ascii  "\r\nBBC BASIC ended - press a key to reboot\r\n\0"

int23:  iret                            # Ctrl-C: negeren (BBC BASIC hookt zelf)
int24:  mov     al, 3                   # kritieke fout: functie laten mislukken
        iret

loader_end:
image:  .incbin "image.lz"
image_end:
        .org    0x8000, 0xFF
