#!/usr/bin/env python3
"""BBCBASIC.EXE -> image.lz (LZSS) + image.inc (parameters voor bbcrom.S).

LZSS-formaat: stuurbyte, 8 bits (LSB eerst): 1 = letterlijk byte,
0 = verwijzing (woord: bits 0-11 = afstand-1, bits 12-15 = lengte-3).
"""
import struct, sys
exe = open(sys.argv[1] if len(sys.argv) > 1 else "BBCBASIC.EXE", "rb").read()
(sig, last, pages, nrel, hdr, minal, maxal, ss, sp, _cs, ip, cs) = struct.unpack("<12H", exe[:24])
assert sig == 0x5A4D, "geen EXE"
assert nrel == 0, "EXE heeft relocaties: deze lader ondersteunt dat niet"
# Zoals MS-DOS: laad het hele bestand na de header, tot pages*512.
# (BBCBASIC.EXE heeft 10 bytes na het opgegeven einde; zijn eigen
#  controlesom over het geheugen rekent die mee.)
img = exe[hdr * 16: min(pages * 512, len(exe))]

def compress(d):
    out = bytearray(); i = 0; n = len(d)
    heads = {}
    while i < n:
        ctrl_pos = len(out); out.append(0); ctrl = 0
        for bit in range(8):
            if i >= n: break
            best_len = 0; best_off = 0
            key = d[i:i+3]
            if len(key) == 3:
                for j in reversed(heads.get(key, [])):
                    off = i - j
                    if off > 4096: break
                    l = 3
                    while l < 18 and i + l < n and d[j + l] == d[i + l]: l += 1
                    if l > best_len: best_len, best_off = l, off
                    if l == 18: break
            if best_len >= 3:
                out += struct.pack("<H", (best_off - 1) | ((best_len - 3) << 12))
                step = best_len
            else:
                ctrl |= 1 << bit; out.append(d[i]); step = 1
            for k in range(i, i + step):
                kk = d[k:k+3]
                if len(kk) == 3: heads.setdefault(kk, []).append(k)
            i += step
        out[ctrl_pos] = ctrl
    return bytes(out)

def decompress(c, n):
    o = bytearray(); i = 0
    while len(o) < n:
        ctrl = c[i]; i += 1
        for bit in range(8):
            if len(o) >= n: break
            if ctrl & (1 << bit): o.append(c[i]); i += 1
            else:
                w = c[i] | c[i+1] << 8; i += 2
                off = (w & 0xFFF) + 1; l = (w >> 12) + 3
                for _ in range(l): o.append(o[-off])
    return bytes(o)

lz = compress(img)
assert decompress(lz, len(img)) == img
open("image.lz", "wb").write(lz)
with open("image.inc", "w") as f:
    f.write(f"# gegenereerd door mkimage.py uit {sys.argv[1] if len(sys.argv)>1 else 'BBCBASIC.EXE'}\n")
    f.write(f"        .equ    IMGSIZE, {len(img)}\n")
    f.write(f"        .equ    EXE_SS, 0x{ss:04X}\n        .equ    EXE_SP, 0x{sp:04X}\n")
    f.write(f"        .equ    EXE_CS, 0x{cs:04X}\n        .equ    EXE_IP, 0x{ip:04X}\n")
    f.write(f"        .equ    EXE_MIN, 0x{minal:04X}\n")
print(f"image {len(img)} bytes -> LZSS {len(lz)} bytes ({100*len(lz)//len(img)}%)")
