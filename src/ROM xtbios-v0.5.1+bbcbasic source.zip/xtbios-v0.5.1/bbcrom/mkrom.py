#!/usr/bin/env python3
"""Logisch 32 KB-image (F600:0000-FDFF:000F) -> fysiek 27256-bestand.

Op de XPC verschijnt de BASIC-socket zo (gemeten met romtest-27256.bin):
  F6000-F7FFF = chip-offset 6000-7FFF,  F8000-FDFFF = chip-offset 0000-5FFF
Het logische byte op F6000+i komt dus op chip-offset (6000h+i) mod 8000h.
"""
import sys
log = open(sys.argv[1], "rb").read()
assert len(log) == 0x8000, "verwacht 32768 bytes"
phys = bytearray(0x8000)
for i, b in enumerate(log):
    phys[(0x6000 + i) & 0x7FFF] = b
open(sys.argv[2], "wb").write(phys)
print(f"{sys.argv[2]}: 32768 bytes (27256, gedraaid voor F600:0000)")
