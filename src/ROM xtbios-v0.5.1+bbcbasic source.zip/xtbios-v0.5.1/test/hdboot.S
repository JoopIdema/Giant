# Bootsector voor de nep-harde schijf: meldt dat hij van C: komt (DL = 80h)
        .intel_syntax noprefix
        .code16
        .arch   i8086
        .text
        .equ    B, 0x7C00
start:  xor     ax, ax
        mov     ds, ax
        mov     ss, ax
        mov     sp, B
        mov     al, dl
        mov     cl, 4
        shr     al, cl
        add     al, '0'
        mov     [B + (dlv - start)], al
        mov     si, B + (msg - start)
1:      lodsb
        or      al, al
        jz      2f
        mov     ah, 0x0E
        mov     bx, 7
        int     0x10
        jmp     1b
2:      xor     ah, ah
        int     0x16
        int     0x19
msg:    .ascii  "Booted from hard disk C: (DL="
dlv:    .ascii  "?0h)\r\n\0"
        .org    510
        .byte   0x55, 0xAA
