# Testbootsector voor xtbios: diskette lezen/schrijven/formatteren,
# toetsenbord-echo (Esc stopt), shift-status en print screen.
        .intel_syntax noprefix
        .code16
        .arch   i8086
        .text
        .equ    B, 0x7C00
start:  xor     ax, ax
        mov     ds, ax
        mov     es, ax
        mov     ss, ax
        mov     sp, B
        mov     si, B + (m_boot - start)
        call    puts
        mov     ax, 0x0202              # sector 2-3 -> 8000
        mov     cx, 0x0002
        xor     dx, dx
        mov     bx, 0x8000
        int     0x13
        jc      fail
        mov     si, 0x8000
        call    puts
        mov     ax, 0x0301              # schrijf C1 H0 S1 uit tekst
        mov     cx, 0x0101
        mov     bx, B + (m_wr - start)
        int     0x13
        jc      fail
        mov     ax, 0x0201              # en lees terug naar 9000
        mov     bx, 0x9000
        int     0x13
        jc      fail
        mov     si, 0x9000
        call    puts
        mov     di, 0xA000              # format C2 H0: ID's C,H,R,N
        mov     cx, 9
        mov     al, 1
1:      mov     byte ptr [di], 2
        mov     byte ptr [di+1], 0
        mov     [di+2], al
        mov     byte ptr [di+3], 2
        add     di, 4
        inc     al
        loop    1b
        mov     ax, 0x0509
        mov     cx, 0x0200
        xor     dx, dx
        mov     bx, 0xA000
        int     0x13
        jc      fail
        mov     si, B + (m_fmt - start)
        call    puts
key:    xor     ah, ah                  # toetsenbord-echo
        int     0x16
        cmp     al, 0x1B
        je      done
        or      al, al
        jz      2f
        cmp     al, 0x0D
        jne     3f
        mov     al, 0x0A
        call    putc
        mov     al, 0x0D
3:      call    putc
        jmp     key
2:      push    ax
        mov     al, '['
        call    putc
        pop     ax
        mov     al, ah
        call    hex
        mov     al, ']'
        call    putc
        jmp     key
done:   mov     si, B + (m_flag - start)
        call    puts
        mov     ah, 2
        int     0x16
        call    hex
        int     0x05                    # print screen
        mov     si, B + (m_end - start)
        call    puts
        xor     ah, ah
        int     0x16
        int     0x19                    # opnieuw opstarten
fail:   push    ax
        mov     si, B + (m_fail - start)
        call    puts
        pop     ax
        mov     al, ah
        call    hex
        cli
        hlt
hex:    push    ax
        mov     cl, 4
        shr     al, cl
        call    nib
        pop     ax
nib:    and     al, 0x0F
        add     al, '0'
        cmp     al, '9'
        jbe     putc
        add     al, 7
putc:   push    bx
        mov     ah, 0x0E
        xor     bx, bx
        int     0x10
        pop     bx
        ret
puts:   lodsb
        or      al, al
        jz      4f
        call    putc
        jmp     puts
4:      ret
m_boot: .ascii  "Bootsector geladen\r\n\0"
m_fmt:  .ascii  "Format C2 OK\r\nTyp maar (Esc = stop):\r\n\0"
m_flag: .ascii  "\r\nShift-status: \0"
m_end:  .ascii  "\r\nKlaar - druk op een toets om opnieuw op te starten\0"
m_fail: .ascii  "INT 13h FOUT \0"
m_wr:   .ascii  "Schrijf+terugleestest OK\r\n\0"
        .org    510
        .byte   0x55, 0xAA
