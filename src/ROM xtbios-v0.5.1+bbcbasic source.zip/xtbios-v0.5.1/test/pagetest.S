# Paginatest (zoals CheckIt): schrijf via INT 10h AH=09/0A naar elke
# niet-actieve pagina en controleer het videogeheugen direct; lees ook
# terug met AH=08. Werkt in mode 1 (40x25, 8 pagina's) en mode 3 (80x25, 4).
        .intel_syntax noprefix
        .code16
        .arch   i8086
        .text
        .equ    B, 0x7C00
start:  xor     ax, ax
        mov     ds, ax
        mov     ss, ax
        mov     sp, B
        mov     byte ptr [B + (fails - start)], 0
        mov     ax, 0x0001
        mov     word ptr [B + (npages - start)], 8
        call    testmode
        mov     ax, 0x0003
        mov     word ptr [B + (npages - start)], 4
        call    testmode
        mov     si, B + (m_ok - start)
        cmp     byte ptr [B + (fails - start)], 0
        je      1f
        mov     si, B + (m_bad - start)
1:      call    puts
        mov     si, B + (m_end - start)
        call    puts
        xor     ah, ah
        int     0x16
        int     0x19

# testmode: AX = mode
testmode:
        int     0x10
        mov     ah, 0x0F
        int     0x10                    # AH = kolommen
        mov     [B + (cols - start)], ah
        mov     bh, 1                   # pagina 1..n-1 (pagina 0 = actief)
2:      mov     ah, 0x02                # cursor rij 1, kolom 2 (als CheckIt)
        mov     dx, 0x0102
        int     0x10
        mov     ax, 0x0941              # AH=09 'A'+pagina, attribuut 1Eh
        add     al, bh
        mov     bl, 0x1E
        mov     cx, 3
        int     0x10
        mov     ah, 0x08                # AH=08 teruglezen
        int     0x10
        mov     dl, 0x41
        add     dl, bh
        cmp     al, dl
        jne     8f
        cmp     ah, 0x1E
        jne     8f
        push    bx                      # videogeheugen direct controleren
        mov     al, bh
        xor     ah, ah
        mov     bx, ax
        mov     al, [B + (cols - start)]
        mov     cl, 25
        mul     cl
        shl     ax, 1                   # paginagrootte (40x25: 2000->800h afgerond)
        add     ax, 0x07FF
        and     ax, 0xF800
        mul     bx                      # begin pagina
        mov     di, ax
        mov     al, [B + (cols - start)]
        xor     ah, ah
        shl     ax, 1
        add     di, ax                  # rij 1
        add     di, 4                   # kolom 2
        mov     ax, 0xB800
        mov     es, ax
        pop     bx
        mov     al, 0x41
        add     al, bh
        mov     ah, 0x1E
        cmp     es:[di], ax
        jne     8f
        cmp     es:[di+4], ax
        jne     8f
        xor     ax, ax                  # pagina 0 mag niet geraakt zijn
        cmp     word ptr es:[0], 0x0720
        je      9f
        cmp     word ptr es:[0], 0x0700
        je      9f
        cmp     word ptr es:[0], 0
        jne     8f
9:      inc     bh
        cmp     bh, [B + (npages - start)]
        jb      2b
        ret
8:      inc     byte ptr [B + (fails - start)]
        mov     al, bh
        add     al, '0'
        mov     [B + (m_pg - start)], al
        xor     bh, bh
        mov     ah, 0x02
        mov     dx, 0x0A00
        int     0x10
        mov     si, B + (m_fail - start)
        call    puts
        ret

puts:   lodsb
        or      al, al
        jz      3f
        mov     ah, 0x0E
        xor     bx, bx
        int     0x10
        jmp     puts
3:      ret

npages: .word   0
cols:   .byte   0
fails:  .byte   0
m_fail: .ascii  "Pagina "
m_pg:   .ascii  "? FOUT\r\n\0"
m_ok:   .ascii  "Paginatest OK (mode 1: 8 pagina's, mode 3: 4 pagina's)\0"
m_bad:  .ascii  "Paginatest MISLUKT\0"
m_end:  .ascii  "\r\nDruk op een toets om opnieuw op te starten\0"
        .org    510
        .byte   0x55, 0xAA
