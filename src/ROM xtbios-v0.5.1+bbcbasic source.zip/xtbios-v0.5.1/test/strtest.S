# Test INT 10h AH=13h (string schrijven) in alle vier modi
        .intel_syntax noprefix
        .code16
        .arch   i8086
        .text
        .equ    B, 0x7C00
start:  xor     ax, ax
        mov     ds, ax
        mov     ss, ax
        mov     sp, B
        mov     es, ax
        mov     ax, 0x0003
        int     0x10
        mov     ax, 0x1300              # modus 0: attribuut BL, cursor blijft
        mov     bx, 0x001E
        mov     cx, offset l1
        mov     dx, 0x0205
        mov     bp, B + (s1 - start)
        int     0x10
        mov     ax, 0x1301              # modus 1: cursor schuift mee
        mov     bx, 0x004F
        mov     cx, offset l2
        mov     dx, 0x0405
        mov     bp, B + (s2 - start)
        int     0x10
        mov     ax, 0x0E21              # '!' na modus 1 -> direct achter tekst
        mov     bx, 0x0007
        int     0x10
        mov     ax, 0x1302              # modus 2: teken/attribuut-paren
        xor     bx, bx
        mov     cx, 5
        mov     dx, 0x0605
        mov     bp, B + (s3 - start)
        int     0x10
        mov     ax, 0x1301              # met CR/LF en omloop op regel 79
        mov     bx, 0x0070
        mov     cx, offset l4
        mov     dx, 0x084C
        mov     bp, B + (s4 - start)
        int     0x10
        xor     ah, ah
        int     0x16
        int     0x19
s1:     .ascii  "Modus 0: geel op blauw, cursor blijft staan"
        .equ    l1, . - s1
s2:     .ascii  "Modus 1: wit op rood, cursor schuift mee"
        .equ    l2, . - s2
s3:     .byte   'K',0x0C, 'L',0x0A, 'E',0x09, 'U',0x0E, 'R',0x0D
s4:     .ascii  "omloop->volgende regel\r\nna CR/LF"
        .equ    l4, . - s4
        .org    510
        .byte   0x55, 0xAA
