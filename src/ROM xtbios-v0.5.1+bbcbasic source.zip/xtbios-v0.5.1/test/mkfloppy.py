#!/usr/bin/env python3
"""Maak floppy.img (360 KB) met de testbootsector en testsectoren."""
img = bytearray(368640)
img[0:512] = open("boot.bin", "rb").read()
def put(c, h, s, txt):
    lba = (c * 2 + h) * 9 + (s - 1)
    b = txt.encode() + b"\0"
    img[lba*512:lba*512+len(b)] = b
put(0, 0, 2, "Sector 2+3 via DMA gelezen\r\n")
open("floppy.img", "wb").write(img)
print("floppy.img gemaakt")
