# Grafische testbootsector voor xtbios v0.3 (INT 10h modi 4 en 6).
# Na elk scherm wacht hij op een toets (de simulator maakt dan een PNG).
        .intel_syntax noprefix
        .code16
        .arch   i8086
        .text
        .equ    B, 0x7C00
start:  xor     ax, ax
        mov     ds, ax
        mov     ss, ax
        mov     sp, B
#--- scherm 1: mode 4, 320x200x4 ---
        mov     ax, 0x0004
        int     0x10
        mov     ax, 0x0B00              # achtergrond blauw
        mov     bx, 0x0001
        int     0x10
        mov     bx, 0x0101              # palet 1 (cyaan/magenta/wit)
        int     0x10
        xor     dx, dx                  # rand: kleur 3
1:      xor     cx, cx
        mov     ax, 0x0C03
        int     0x10
        mov     cx, 319
        int     0x10
        inc     dx
        cmp     dx, 200
        jb      1b
        xor     cx, cx
2:      xor     dx, dx
        mov     ax, 0x0C03
        int     0x10
        mov     dx, 199
        int     0x10
        inc     cx
        cmp     cx, 320
        jb      2b
        mov     cx, 40                  # diagonalen kleur 1 en 2
3:      mov     dx, cx
        mov     ax, 0x0C01
        int     0x10
        push    cx
        add     cx, 100
        mov     ax, 0x0C02
        int     0x10
        pop     cx
        inc     cx
        cmp     cx, 190
        jb      3b
        mov     dx, 0x0202              # tekst via teletype, kleur 3
        call    setcur
        mov     si, B + (m1 - start)
        mov     bl, 3
        call    puts
        mov     dx, 0x0402              # AH=09: 10x '*' kleur 2
        call    setcur
        mov     ax, 0x092A
        mov     bx, 0x0002
        mov     cx, 10
        int     0x10
        mov     dx, 0x0502              # AH=09 met XOR over tekst heen
        call    setcur
        mov     si, B + (m1 - start)
        mov     bl, 1
        call    puts
        mov     dx, 0x0502
        call    setcur
        mov     ax, 0x095F
        mov     bx, 0x0083
        mov     cx, 5
        int     0x10
        mov     dx, 0x0202              # AH=08: teken terug lezen
        call    setcur
        mov     ah, 0x08
        int     0x10
        mov     [B + (r_chr - start)], al
        mov     dx, 100                 # AH=0D: pixel terug lezen (diagonaal 1)
        mov     cx, 100
        mov     ah, 0x0D
        int     0x10
        add     al, '0'
        mov     [B + (r_pix - start)], al
        mov     dx, 0x1502
        call    setcur
        mov     si, B + (m_res - start)
        mov     bl, 3
        call    puts
        xor     ah, ah
        int     0x16
#--- scherm 2: mode 6, 640x200x2, scrollen ---
        mov     ax, 0x0006
        int     0x10
        mov     cx, 0                   # horizontale lijn op y=196
4:      mov     dx, 196
        mov     ax, 0x0C01
        int     0x10
        inc     cx
        cmp     cx, 640
        jb      4b
        mov     cx, 30                  # 30 regels: scrollt 5x
5:      push    cx
        mov     si, B + (m2 - start)
        mov     bl, 1
        call    puts
        pop     cx
        loop    5b
        mov     ax, 0x0702              # AH=07: venster 2 regels omlaag
        mov     bh, 0
        mov     cx, 0x0000
        mov     dx, 0x0A13
        int     0x10
        xor     ah, ah
        int     0x16
#--- scherm 3: terug naar tekstmode ---
        mov     ax, 0x0003
        int     0x10
        mov     si, B + (m3 - start)
        mov     bl, 7
        call    puts
        mov     si, B + (m_end - start)
        call    puts
        xor     ah, ah
        int     0x16
        int     0x19                    # opnieuw opstarten
setcur: mov     ah, 0x02
        xor     bh, bh
        int     0x10
        ret
puts:   lodsb
        or      al, al
        jz      9f
        mov     ah, 0x0E
        int     0x10
        jmp     puts
9:      ret
m1:     .ascii  "Hallo CGA 320x200!\0"
m_res:  .ascii  "AH=08 leest: '"
r_chr:  .ascii  "?'  AH=0D pixel: "
r_pix:  .ascii  "?\0"
m2:     .ascii  "Mode 6: 640x200 - scrollen werkt \x01 \x03 \x0E\r\n\0"
m_end:  .ascii  "\r\n\r\nTest klaar - druk op een toets om opnieuw op te starten\0"
m3:     .ascii  "Terug in tekstmode 3. Font: \x01\x02\x03\x04\x05\x06 ABC abc 123\0"
        .org    510
        .byte   0x55, 0xAA
