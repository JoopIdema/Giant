# fakehd.S - nep-harde-schijf-option-ROM voor de simulator (C800:0000, 2 KB).
# Gedraagt zich in het klein als een XT-IDE-ROM: neemt INT 13h over voor
# DL >= 80h (oude vector naar INT 40h), meldt 1 schijf in 0040:0075 en
# laat de simulator sectoren kopiëren via poort E1h.
        .intel_syntax noprefix
        .code16
        .arch   i8086
        .text
        .byte   0x55, 0xAA, 4           # 4 x 512 bytes
        jmp     init
init:   push    ax
        push    ds
        push    si
        xor     ax, ax
        mov     ds, ax
        cmp     byte ptr ds:[0x475], 0  # (zoals vermoed bij XT-IDE:) lijkt al
        jne     2f                      # geïnstalleerd -> niets doen
        mov     ax, ds:[0x13*4]         # oude INT 13h -> INT 40h
        mov     ds:[0x40*4], ax
        mov     ax, ds:[0x13*4+2]
        mov     ds:[0x40*4+2], ax
        mov     word ptr ds:[0x13*4], offset int13
        mov     ds:[0x13*4+2], cs
        mov     byte ptr ds:[0x475], 1  # 1 harde schijf
        mov     si, offset msg
1:      mov     al, cs:[si]
        inc     si
        or      al, al
        jz      2f
        mov     ah, 0x0E
        mov     bx, 7
        int     0x10
        jmp     1b
2:      pop     si
        pop     ds
        pop     ax
        retf
int13:  cmp     dl, 0x80
        jae     hd
        int     0x40                    # diskette: oude handler
        retf    2
hd:     or      ah, ah
        jz      ok
        cmp     ah, 0x02
        jne     bad
        out     0xE1, al                # simulator: lees AL sectoren naar ES:BX
        mov     ah, 0
        clc
        retf    2
ok:     clc
        retf    2
bad:    mov     ah, 0x01
        stc
        retf    2
msg:    .ascii  "FakeHD option ROM (simulator) - 1 drive\r\n\0"
        .org    2047
        .byte   0
