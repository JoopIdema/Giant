"""Mini XT-simulator rond Unicorn om de BIOS te testen.

Gemodelleerd: 8259 PIC, PIT-ticks (grof), 8255 PPI incl. toetsenbord (reset/AAh,
scancodes, PB7-ack), DMA kanaal 2, NEC 765 (recal/seek/read/write/format),
6845 CRTC voor CGA en MDA, optioneel een LPT-poort op 378h die tekens opvangt.

Gebruik: python3 xtsim.py ROM IMG [cga|mda] [opties]
  opties: nodisk   geen leesbare diskette
          lpt      printerpoort op 378h
          keys=... toetsenscript (zie KEYS hieronder) na het booten
"""
import sys, os
from unicorn import Uc, UcError, UC_ARCH_X86, UC_MODE_16, UC_HOOK_INSN, UC_HOOK_INTR
from unicorn.x86_const import *

rom = open(sys.argv[1], 'rb').read()
img = bytearray(open(sys.argv[2], 'rb').read())
VIDEO = sys.argv[3] if len(sys.argv) > 3 else 'cga'
OPTS = sys.argv[4:]
NODISK = 'nodisk' in OPTS
HAS_LPT = 'lpt' in OPTS
KEYSCRIPT = next((o[5:] for o in OPTS if o.startswith('keys=')), '')
import os
MAXCH = int(os.environ.get("MAXCH", 8000 if NODISK else 60000))

uc = Uc(UC_ARCH_X86, UC_MODE_16)
MEMKB = int(next((o[4:] for o in OPTS if o.startswith('mem=')), '640'))
BADRAM = int(next((o[7:] for o in OPTS if o.startswith('badram=')), '0'), 16)
NOVIDEO = 'novideo' in OPTS
HDIMG = next((o[3:] for o in OPTS if o.startswith('hd=')), '')
hdimg = bytearray(open(HDIMG, 'rb').read()) if HDIMG else None
if 'badsum' in OPTS:
    rom = bytearray(rom); rom[0x10] ^= 0x01; rom = bytes(rom)

# RAM tot MEMKB; daarboven tot A0000 'geen geheugen' (leest FFh)
uc.mem_map(0, MEMKB * 1024)
if MEMKB < 640:
    uc.mmio_map(MEMKB * 1024, 0xA0000 - MEMKB * 1024,
                lambda uc, off, size, ud: (1 << (8 * size)) - 1, None,
                lambda uc, off, size, val, ud: None, None)
uc.mem_map(0xA0000, 0x60000)
uc.mem_write(0xFE000, rom)
ROM2 = next((o[5:] for o in OPTS if o.startswith('rom2=')), '')
if ROM2:                                       # BASIC-socket, logische volgorde
    uc.mem_write(0xF6000, open(ROM2, 'rb').read()[:0x8000])
dos_unknown = []
if hdimg is not None:
    uc.mem_write(0xC8000, open(os.path.join(os.path.dirname(sys.argv[0]) or '.', 'fakehd.bin'), 'rb').read())
if BADRAM:                                    # één byte met bit 0 'vast op 1'
    pg = BADRAM & ~0xFFF
    store = bytearray(4096)
    uc.mem_unmap(pg, 4096)
    def bad_rd(uc, off, size, ud):
        v = int.from_bytes(store[off:off+size], 'little')
        if off <= (BADRAM & 0xFFF) < off + size: v |= 1 << (8 * ((BADRAM & 0xFFF) - off))
        return v
    def bad_wr(uc, off, size, val, ud):
        store[off:off+size] = val.to_bytes(size, 'little')
    uc.mmio_map(pg, 4096, bad_rd, None, bad_wr, None)
speaker = {'on': 0, 'state': False}
log, post_codes, printer = [], [], bytearray()

# ---- toetsenbord: scancodes (set 1) ----------------------------------------
SC = {}
for row, base in (("1234567890-=", 2), ("qwertyuiop[]", 0x10), ("asdfghjkl;'`", 0x1E), ("\\zxcvbnm,./", 0x2B)):
    for i, ch in enumerate(row):
        SC[ch] = base + i
SHIFTED = dict(zip('!@#$%^&*()_+{}:"~|<>?', '1234567890-=[];\'`\\,./'))
NAMED = {'ENTER': 0x1C, 'ESC': 0x01, 'TAB': 0x0F, 'BS': 0x0E, 'SPACE': 0x39, 'CAPS': 0x3A,
         'NUM': 0x45, 'SCROLL': 0x46, 'F1': 0x3B, 'F10': 0x44, 'UP': 0x48, 'LEFT': 0x4B,
         'HOME': 0x47, 'INS': 0x52, 'DEL': 0x53, 'PRTSC': 0x37,
         'KP0': 0x52, 'KP1': 0x4F, 'KP2': 0x50, 'KP3': 0x51, 'KP4': 0x4B, 'KP5': 0x4C,
         'KP6': 0x4D, 'KP7': 0x47, 'KP8': 0x48, 'KP9': 0x49,
         'LSHIFT': 0x2A, 'CTRL': 0x1D, 'ALT': 0x38}

def keyscript(script):
    """Tekst met {NAAM} voor speciale toetsen, {+NAAM}/{-NAAM} voor indrukken/loslaten."""
    out, i = [], 0
    while i < len(script):
        c = script[i]
        if c == '{':
            j = script.index('}', i); tok = script[i+1:j]; i = j + 1
            if tok[0] in '+-':
                code = NAMED[tok[1:]]; out.append(code if tok[0] == '+' else code | 0x80)
            else:
                code = NAMED[tok]; out += [code, code | 0x80]
            continue
        i += 1
        if c == ' ': out += [0x39, 0xB9]; continue
        shift = c.isupper() or c in SHIFTED
        base = SHIFTED.get(c, c.lower())
        code = SC[base]
        if shift: out.append(0x2A)
        out += [code, code | 0x80]
        if shift: out.append(0xAA)
    return out

kbd = {'queue': [], 'cur': 0, 'busy': False, 'gap': 0}
script_codes = keyscript(KEYSCRIPT)
booted = False

class PIC:
    mask = 0xFF; isr = 0; irr = 0; read_isr = False; init = 0
pic = PIC()
ppi_b = 0
switches = 0b01_10_11_01 if VIDEO == 'cga' else 0b01_11_11_01
crtc = {0x3D4: [0, [0]*18], 0x3B4: [0, [0]*18]}
dma = {'ff': 0, 'addr2': 0, 'cnt2': 0, 'page2': 0}
lpt = {'data': 0, 'ctrl': 0x0C}

class FDC:
    dor = 0; cmd = []; res = []; need = 0; pending_sense = []; cyl = [0]*4
fdc = FDC()
PARAMS = {0x03: 3, 0x07: 2, 0x08: 1, 0x0F: 3, 0x06: 9, 0x05: 9, 0x0D: 6}

def raise_irq(n): pic.irr |= 1 << n

def fdc_exec():
    c = fdc.cmd; op = c[0] & 0x1F
    fdc.cmd = []
    if op == 0x03: return
    if op == 0x08:
        fdc.res = list(fdc.pending_sense.pop(0)) if fdc.pending_sense else [0x80]; return
    if op == 0x07:
        d = c[1] & 3; fdc.cyl[d] = 0
        fdc.pending_sense.append((0x20 | d, 0)); raise_irq(6); return
    if op == 0x0F:
        d = c[1] & 3; fdc.cyl[d] = c[2]
        fdc.pending_sense.append((0x20 | d, c[2])); raise_irq(6); return
    if op == 0x0D:
        d = c[1] & 3; H = (c[1] >> 2) & 1; n = dma['cnt2'] + 1
        addr = (dma['page2'] << 16) | dma['addr2']
        ids = bytes(uc.mem_read(addr, n))
        log.append(f"FDC FORMAT C{fdc.cyl[d]} H{H} SC={c[3]} vul={c[5]:02X} ids={ids[:8].hex()}..")
        lba = (fdc.cyl[d] * 2 + H) * 9
        img[lba*512:(lba+9)*512] = bytes([c[5]]) * (9*512)
        fdc.res = [d | (H << 2), 0, 0, fdc.cyl[d], H, 1, 2]; raise_irq(6); return
    if op in (0x06, 0x05):
        d = c[1] & 3; C, H, R, N = c[2], c[3], c[4], c[5]
        if NODISK:
            fdc.res = [0x40 | d, 0x01, 0, C, H, R, N]; raise_irq(6); return
        if C != fdc.cyl[d]:
            fdc.res = [0x40 | d, 0x04, 0, C, H, R, N]; raise_irq(6); return
        addr = (dma['page2'] << 16) | dma['addr2']; n = dma['cnt2'] + 1
        lba = (C * 2 + H) * 9 + (R - 1)
        if op == 0x06:
            uc.mem_write(addr, bytes(img[lba*512: lba*512 + n]))
        else:
            img[lba*512: lba*512+n] = uc.mem_read(addr, n)
        log.append(f"FDC {'READ' if op==6 else 'WRITE'} C{C} H{H} R{R} x{n//512} @ {addr:05X}")
        fdc.res = [d | (H << 2), 0, 0, C, H, R + n // 512, N]; raise_irq(6); return
    fdc.res = [0x80]

def port_in(uc, port, size, ud):
    if port == 0x20: return pic.isr if pic.read_isr else pic.irr
    if port == 0x21: return pic.mask
    if port == 0x60: return kbd['cur']
    if port == 0x61: return ppi_b
    if port == 0x62:
        return (switches >> 4) & 0xF if ppi_b & 0x08 else switches & 0xF
    if port in (0x3D5, 0x3B5):
        if NOVIDEO: return 0xFF
        if VIDEO == 'cga' and port == 0x3B5: return 0xFF
        if VIDEO == 'mda' and port == 0x3D5: return 0xFF
        b = crtc[port - 1]; return b[1][b[0]] if b[0] < 18 else 0xFF
    if port == 0x3F4: return 0xD0 if fdc.res else 0x80
    if port == 0x3F5: return fdc.res.pop(0) if fdc.res else 0
    if HAS_LPT and port == 0x378: return lpt['data']
    if HAS_LPT and port == 0x379: return 0xD8          # niet bezig, geselecteerd, geen fout
    if HAS_LPT and port == 0x37A: return lpt['ctrl']
    return 0xFF

def port_out(uc, port, size, val, ud):
    global ppi_b
    val &= 0xFF
    if port == 0x80: post_codes.append(val)
    elif port == 0x20:
        if val & 0x10: pic.init = 1
        elif val == 0x20:
            for i in range(8):
                if pic.isr & (1 << i): pic.isr &= ~(1 << i); break
        elif val == 0x0B: pic.read_isr = True
        elif val == 0x0A: pic.read_isr = False
    elif port == 0x21:
        if pic.init: pic.init = pic.init + 1 if pic.init < 3 else 0
        if pic.init == 0: pic.mask = val
    elif port == 0xE3:
        dos_unknown.append(val)
    elif port == 0xE1 and hdimg is not None:     # nep-harde-schijf: AL sectoren
        n = val; bx = uc.reg_read(UC_X86_REG_BX); es = uc.reg_read(UC_X86_REG_ES)
        cx = uc.reg_read(UC_X86_REG_CX); dh = uc.reg_read(UC_X86_REG_DX) >> 8
        cyl = (cx >> 8) | ((cx & 0xC0) << 2); sec = cx & 0x3F
        lba = (cyl * 4 + dh) * 17 + sec - 1
        uc.mem_write((es << 4) + bx, bytes(hdimg[lba*512:(lba+n)*512]))
        log.append(f"HD READ C{cyl} H{dh} S{sec} x{n} @ {(es<<4)+bx:05X}")
    elif port == 0x61:
        on = (val & 3) == 3
        if on and not speaker['state']: speaker['on'] += 1
        speaker['state'] = on
        old = ppi_b; ppi_b = val
        if not (old & 0x40) and (val & 0x40):        # klok losgelaten -> reset
            kbd['queue'] = ([0x9D, 0xB8, 0xD3] if 'kbbreak' in OPTS and post_codes.count(1) > 1 else []) + [0xAA]
            kbd['busy'] = False; kbd['gap'] = 3
            if 'keyspost' in OPTS:                     # toetsen direct na de reset
                global booted
                booted = True; kbd['queue'] += script_codes; kbd['gap'] = 40
        if not (old & 0x80) and (val & 0x80):        # ack: register leeg
            kbd['cur'] = 0; kbd['busy'] = False; pic.irr &= ~2
    elif port in (0x3D4, 0x3B4): crtc[port][0] = val
    elif port in (0x3D5, 0x3B5):
        b = crtc[port - 1]
        if b[0] < 18: b[1][b[0]] = val
    elif port == 0x0C: dma['ff'] = 0
    elif port in (0x04, 0x05):
        k = 'addr2' if port == 0x04 else 'cnt2'
        dma[k] = (dma[k] & 0xFF00) | val if dma['ff'] == 0 else (dma[k] & 0x00FF) | (val << 8)
        dma['ff'] ^= 1
    elif port == 0x81: dma['page2'] = val
    elif port == 0x3F2:
        if (fdc.dor & 4) == 0 and (val & 4):
            fdc.pending_sense = [(0xC0 | d, 0) for d in range(4)]; raise_irq(6)
        fdc.dor = val
    elif port == 0x3F5:
        if not fdc.cmd: fdc.need = PARAMS.get(val & 0x1F, 1)
        fdc.cmd.append(val)
        if len(fdc.cmd) >= fdc.need: fdc_exec()
    elif HAS_LPT and port == 0x378: lpt['data'] = val
    elif HAS_LPT and port == 0x37A:
        if (lpt['ctrl'] & 1) and not (val & 1): printer.append(lpt['data'])   # strobe
        lpt['ctrl'] = val

uc.hook_add(UC_HOOK_INSN, port_in, None, 1, 0, UC_X86_INS_IN)
uc.hook_add(UC_HOOK_INSN, port_out, None, 1, 0, UC_X86_INS_OUT)

def do_int(vec):
    fl = uc.reg_read(UC_X86_REG_EFLAGS)
    sp = uc.reg_read(UC_X86_REG_SP); ss = uc.reg_read(UC_X86_REG_SS)
    for w in (fl & 0xFFFF, uc.reg_read(UC_X86_REG_CS), uc.reg_read(UC_X86_REG_IP)):
        sp = (sp - 2) & 0xFFFF; uc.mem_write((ss << 4) + sp, w.to_bytes(2, 'little'))
    uc.reg_write(UC_X86_REG_SP, sp)
    uc.reg_write(UC_X86_REG_EFLAGS, fl & ~0x300)
    ip = int.from_bytes(uc.mem_read(vec*4, 2), 'little')
    cs = int.from_bytes(uc.mem_read(vec*4+2, 2), 'little')
    uc.reg_write(UC_X86_REG_CS, cs); uc.reg_write(UC_X86_REG_IP, ip)

shots = []
def snapshot():
    from PIL import Image
    bda = uc.mem_read(0x400, 0x100)
    mode, pal = bda[0x49], bda[0x66]
    CGA = [(0,0,0),(0,0,170),(0,170,0),(0,170,170),(170,0,0),(170,0,170),(170,85,0),(170,170,170),
           (85,85,85),(85,85,255),(85,255,85),(85,255,255),(255,85,85),(255,85,255),(255,255,85),(255,255,255)]
    if mode in (4, 5, 6):
        vram = uc.mem_read(0xB8000, 0x4000)
        w = 640 if mode == 6 else 320
        im = Image.new('RGB', (w, 200))
        if mode == 6:
            cols = [(0,0,0), CGA[pal & 15]]
        else:
            base = [2, 4, 6] if not (pal & 0x20) else [3, 5, 7]
            if mode == 5: base = [3, 4, 7]
            hi = 8 if pal & 0x10 else 0
            cols = [CGA[pal & 15]] + [CGA[b + hi] for b in base]
        px = im.load()
        for y in range(200):
            row = vram[(y & 1) * 0x2000 + (y >> 1) * 80:][:80]
            for x in range(w):
                if mode == 6: c = (row[x >> 3] >> (7 - (x & 7))) & 1
                else: c = (row[x >> 2] >> ((3 - (x & 3)) * 2)) & 3
                px[x, y] = cols[c]
        im = im.resize((640, 400) if mode == 6 else (640, 400), Image.NEAREST)
    else:
        cols_n = bda[0x4A]
        seg = 0xB000 if mode == 7 else 0xB800
        vram = uc.mem_read(seg << 4, cols_n * 25 * 2)
        font = uc.mem_read(0xFFA6E, 1024)
        im = Image.new('RGB', (cols_n * 8, 200)); px = im.load()
        for r in range(25):
            for c in range(cols_n):
                ch, at = vram[(r*cols_n+c)*2], vram[(r*cols_n+c)*2+1]
                fg, bg = CGA[at & 15], CGA[(at >> 4) & 7]
                g = font[(ch & 0x7F)*8:(ch & 0x7F)*8+8]
                for y in range(8):
                    for x in range(8):
                        px[c*8+x, r*8+y] = fg if g[y] & (0x80 >> x) else bg
        im = im.resize((640, 400), Image.NEAREST)
    name = f"{SHOTDIR}/shot{len(shots)+1}.png"
    im.save(name); shots.append(name)

SHOTDIR = next((o[5:] for o in OPTS if o.startswith('shot=')), '')

from collections import Counter
int_count = Counter()
def hook_intr(uc, intno, ud):
    global booted
    if ROM2 and intno in (0x21, 0x16, 0x10): int_count[(intno, uc.reg_read(UC_X86_REG_AX) >> 8)] += 1
    if intno == 0x16 and SHOTDIR and (uc.reg_read(UC_X86_REG_AX) >> 8) == 0:
        snapshot()
    if ROM2 and not booted:                       # BBC BASIC: pas typen bij de prompt
        if int_count[(0x21, 6)] > 200: booted = True; kbd['queue'] += script_codes
    elif intno == 0x16 and not booted:            # programma vraagt om toetsen
        booted = True; kbd['queue'] += script_codes
    # hardware-IRQ die wacht en IF=1: eerst die afhandelen, INT n daarna opnieuw
    ip = uc.reg_read(UC_X86_REG_IP); cs_ = uc.reg_read(UC_X86_REG_CS)
    if (uc.reg_read(UC_X86_REG_EFLAGS) & 0x200) and (pic.irr & ~pic.mask) and not pic.isr \
            and intno >= 0x10 and uc.mem_read((cs_ << 4) + ip - 2, 1)[0] == 0xCD:
        uc.reg_write(UC_X86_REG_IP, ip - 2)
        deliver(); uc.emu_stop(); return
    do_int(intno); uc.emu_stop()
uc.hook_add(UC_HOOK_INTR, hook_intr)

def linear():
    return (uc.reg_read(UC_X86_REG_CS) << 4) + uc.reg_read(UC_X86_REG_IP)

def deliver():
    if not (uc.reg_read(UC_X86_REG_EFLAGS) & 0x200): return
    pend = pic.irr & ~pic.mask
    for i in range(8):
        if pic.isr & (1 << i): return
        if pend & (1 << i):
            pic.irr &= ~(1 << i); pic.isr |= 1 << i; do_int(8 + i); return

def keyboard_step():
    if kbd['gap'] > 0: kbd['gap'] -= 1; return
    if not kbd['busy'] and kbd['queue'] and (ppi_b & 0xC0) == 0x40:
        if kbd['queue'][0] != 0xAA and not booted: return
        kbd['cur'] = kbd['queue'].pop(0); kbd['busy'] = True; raise_irq(1); kbd['gap'] = int(os.environ.get('KGAP', 6))
        if os.environ.get('KLOG'): print("scancode %02X buf %s" % (kbd['cur'], bytes(uc.mem_read(0x41A, 4)).hex()))

uc.reg_write(UC_X86_REG_CS, 0xF000); uc.reg_write(UC_X86_REG_IP, 0xFFF0)
halted = False
for step in range(1, MAXCH):
    try:
        uc.emu_start(linear(), 0xFFFFFFFF, count=500)
    except UcError as e:
        print("CPU-fout:", e, hex(linear())); break
    if step % 4 == 0: raise_irq(0)
    keyboard_step()
    if uc.mem_read(linear() - 1, 1)[0] == 0xF4:      # HLT
        if not (uc.reg_read(UC_X86_REG_EFLAGS) & 0x200): halted = True; break
        if not (pic.irr & ~pic.mask): raise_irq(0)   # alleen tikken als niets anders wacht
    deliver()

def screen(seg, cols=80):
    data = uc.mem_read(seg << 4, cols*25*2)
    rows = [bytes(data[r*cols*2:(r+1)*cols*2:2]).decode('cp437').rstrip() for r in range(25)]
    while rows and not rows[-1]: rows.pop()
    return "\n".join(rows)

if SHOTDIR: snapshot(); print("schermafdrukken:", " ".join(shots))
bda = uc.mem_read(0x400, 0x100)
w = lambda o: int.from_bytes(bda[o:o+2], 'little')
print("POST-codes:", " ".join(f"{c:02X}" for c in post_codes))
print("gestopt op", hex(linear()), "(HLT met IF=0)" if halted else "")
print("luidspreker: %d keer aan" % speaker['on'])
if ROM2: print("INT-aanroepen:", " ".join("%02X/%02X:%d" % (a, b, c) for (a, b), c in sorted(int_count.items())))
if ROM2: print("onbekende INT 21h-functies:", " ".join("%02X" % v for v in dos_unknown) or "geen")
print("BDA: equip=%04X mem=%dKB mode=%d COM1=%04X LPT1=%04X kbflag=%02X ticks=%d" % (
    w(0x10), w(0x13), bda[0x49], w(0x00), w(0x08), bda[0x17], w(0x6C)))
for l in log: print(" ", l)
if HAS_LPT: print("printer ontving %d bytes" % len(printer))
print("=" * 80)
if not NOVIDEO: print(screen(0xB800 if VIDEO == 'cga' else 0xB000))
print("=" * 80)
if HAS_LPT and printer:
    print("--- printeruitvoer ---")
    print(printer.decode('cp437', 'replace').replace('\r', '').rstrip())
