#!/usr/bin/env python3
"""Controleer grootte en zet checksumbyte (F000:FFFF) zodat de 8 KB optelt tot 0."""
import sys
path = sys.argv[1]
rom = bytearray(open(path, "rb").read())
if len(rom) != 8192:
    sys.exit(f"fout: ROM is {len(rom)} bytes, verwacht 8192")
rom[-1] = 0
rom[-1] = (-sum(rom)) & 0xFF
open(path, "wb").write(rom)
print(f"{path}: 8192 bytes, checksum-byte = {rom[-1]:02X}")
