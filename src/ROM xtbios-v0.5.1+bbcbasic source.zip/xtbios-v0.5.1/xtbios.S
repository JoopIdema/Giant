#=============================================================================
#  xtbios.S  -  GIANT XT-BIOS, v0.5.1 (clean-room hobbyproject)
#
#  Clean-room hobbyproject: geschreven op basis van publieke hardware-
#  specificaties (8088, 8253, 8237, 8259, 8255, 6845, 8250, NEC 765) en de
#  publiek bekende BIOS-interface (INT-nummers, registers, BDA-layout,
#  vaste entry points). Geen bestaande BIOS-code gebruikt.
#
#  ROM: 8 KB op F000:E000-F000:FFFF
#  Bouwen: zie Makefile (GNU binutils, .arch i8086 bewaakt de instructieset)
#
#  v0.1: POST, INT 10h tekst, INT 13h diskette, INT 19h, option-ROMs,
#        INT 08h/0Eh/11h/12h/1Ah
#  v0.2: toetsenbord (INT 09h/16h, reset + zelftest in POST),
#        INT 14h serieel (8250), INT 17h printer, INT 05h print screen,
#        INT 13h AH=05 formatteren, detectie COM/LPT-poorten,
#        Ctrl-Alt-Del, Ctrl-Break, Pause, Alt+numeriek, NMI aan na POST
#  v0.3: eigen 8x8-font (FA6E), INT 10h grafische modi 4/5/6: pixels
#        (0Ch/0Dh), tekst (08h/09h/0Ah/0Eh), scrollen (06h/07h),
#        palet (0Bh), lichtpen-stub (04h); INT 1Fh voor tekens 80h-FFh
#  v0.3.1: INT 10h AH=08/09/0Ah gebruiken pagina BH i.p.v. actieve pagina
#        (CheckIt 2.11: "Video Page #3 Failed")
#  v0.4: booten van harde schijf (C:) na A:, snelle warme start,
#        piepcodes bij POST-fouten en zonder video, 8087-detectie,
#        CPU-detectie (8088/V20), configuratieoverzicht, zichtbare
#        geheugentest met foutadres, INT 10h AH=13h (string schrijven)
#  v0.4.1: warme start wist het geheugen weer (XT-IDE bootte niet na
#        Ctrl-Alt-Del); toetsenbordtest slaat bytes vóór AAh over
#  v0.4.2: naam "IMACOM XT-BIOS"; versienummer op één plek (BIOS_NAME)
#  v0.5: INT 18h start BBC BASIC uit de BASIC-socket (F600:0000, "BBCROM");
#        tijdens de POST ~1,5 s "Press B for BBC BASIC"
#  v0.5.1: naam "GIANT XT-BIOS" (naar de Cardiff Giant uit Halt and Catch Fire)
#=============================================================================

        .intel_syntax noprefix
        .code16
        .arch   i8086
        .text

#--- Naam en versie: alleen hier aanpassen ----------------------------------
        .macro  BIOS_NAME
        .ascii  "GIANT XT-BIOS v0.5.1"
        .endm

        .macro  AT addr                 # zet code op vast adres (F000:addr)
        .org    \addr - 0xE000, 0xFF
        .endm

        .macro  call_free_delay         # wacht DL x 65536 LOOP-slagen (geen stack)
        xor     cx, cx
91:     loop    91b
        dec     dl
        jnz     91b
        .endm

        .macro  POSTCODE code           # voortgang naar POST-kaart (poort 80h)
        mov     al, \code
        out     0x80, al
        .endm

#--- BIOS Data Area (segment 0040h) -----------------------------------------
        .equ    BDA,        0x40
        .equ    COM_BASE,   0x00        # 4 woorden: I/O-adressen COM1-4
        .equ    LPT_BASE,   0x08        # 3 woorden: I/O-adressen LPT1-3
        .equ    EQUIP,      0x10        # equipment word
        .equ    MEMSIZE,    0x13        # geheugen in KB
        .equ    KB_FLAG,    0x17        # shift-status
        .equ    KB_FLAG1,   0x18        # ingedrukte toggle-toetsen, pauze
        .equ    ALT_INPUT,  0x19        # Alt+numeriek accumulator
        .equ    KB_HEAD,    0x1A
        .equ    KB_TAIL,    0x1C
        .equ    KB_BUF,     0x1E
        .equ    SEEK_ST,    0x3E        # bit0-3: gerecalibreerd, bit7: IRQ6 gezien
        .equ    MOTOR_ST,   0x3F        # bit0-3: motor aan
        .equ    MOTOR_CNT,  0x40        # ticks tot motor uit
        .equ    DISK_ST,    0x41        # status laatste disk-operatie
        .equ    FDC_RES,    0x42        # 7 resultaatbytes van de FDC
        .equ    VMODE,      0x49
        .equ    VCOLS,      0x4A
        .equ    VPAGESZ,    0x4C
        .equ    VSTART,     0x4E
        .equ    VCURPOS,    0x50        # 8 woorden: cursor per pagina
        .equ    VCURTYPE,   0x60
        .equ    VPAGE,      0x62
        .equ    VCRTC,      0x63
        .equ    VMODEREG,   0x65
        .equ    VPAL,       0x66
        .equ    ROMINIT,    0x67        # far pointer voor option-ROM init
        .equ    LAST_IRQ,   0x6B
        .equ    TIMER_LO,   0x6C
        .equ    TIMER_HI,   0x6E
        .equ    TIMER_OFL,  0x70
        .equ    BREAK_FLAG, 0x71
        .equ    RESET_FLAG, 0x72        # 1234h = warme start
        .equ    LPT_TMO,    0x78        # 3 bytes printer-time-outs
        .equ    COM_TMO,    0x7C        # 4 bytes serieel-time-outs
        .equ    KB_START,   0x80
        .equ    KB_END,     0x82

        # KB_FLAG-bits
        .equ    KF_RSHIFT,  0x01
        .equ    KF_LSHIFT,  0x02
        .equ    KF_CTRL,    0x04
        .equ    KF_ALT,     0x08
        .equ    KF_SCROLL,  0x10
        .equ    KF_NUM,     0x20
        .equ    KF_CAPS,    0x40
        .equ    KF_INS,     0x80
        .equ    KF1_HOLD,   0x08        # in KB_FLAG1: pauze actief

#=============================================================================
AT 0xE000
ident:  BIOS_NAME
        .ascii  " - clean-room hobby build\0"

#=============================================================================
AT 0xE05B                               # vaste entry: POST / koude start
reset_entry:
        jmp     post_start

#--- Hulproutines (POST) -----------------------------------------------------

# read_switches -> AL = SW1..SW8 (XT: poort 61h bit3 kiest hoge/lage nibble)
read_switches:
        in      al, 0x61
        or      al, 0x08
        out     0x61, al
        in      al, 0x62
        and     al, 0x0F
        mov     cl, 4
        shl     al, cl
        mov     ah, al
        in      al, 0x61
        and     al, 0xF7
        out     0x61, al
        in      al, 0x62
        and     al, 0x0F
        or      al, ah
        ret

# detect_video -> AH = 20h (CGA 80x25), 30h (MDA) of 00h (geen / EGA-VGA)
detect_video:
        mov     dx, 0x3D4
        call    probe_crtc
        mov     ah, 0x20
        jnc     1f
        mov     dx, 0x3B4
        call    probe_crtc
        mov     ah, 0x30
        jnc     1f
        xor     ah, ah
1:      ret

probe_crtc:                             # DX = indexpoort; CF=0 als aanwezig
        mov     al, 0x0F
        out     dx, al
        inc     dx
        in      al, dx
        mov     bl, al
        mov     al, 0x5A
        out     dx, al
        jmp     2f
2:      in      al, dx
        xchg    al, bl
        out     dx, al
        dec     dx
        cmp     bl, 0x5A
        je      3f
        stc
        ret
3:      clc
        ret

# init_vectors: INT 00-1F vullen
init_vectors:
        push    ds
        xor     ax, ax
        mov     es, ax
        xor     di, di
        mov     cx, 8                   # INT 00-07 -> dummy
1:      mov     ax, offset dummy_int
        stosw
        mov     ax, cs
        stosw
        loop    1b
        mov     word ptr es:[0x02*4], offset nmi_int
        mov     word ptr es:[0x05*4], offset int05
        mov     ax, cs
        mov     ds, ax
        mov     si, offset vector_table # INT 08-1F uit tabel
        mov     cx, 24
2:      movsw
        mov     ax, cs
        stosw
        loop    2b
        xor     ax, ax                  # INT 1Fh = 0000:0000 (geen font)
        mov     es:[0x1F*4], ax
        mov     es:[0x1F*4+2], ax
        pop     ds
        ret

# rom_scan: zoek option-ROMs (55AAh) van segment DX tot BX, stappen van 2 KB
rom_scan:
1:      mov     ds, dx
        cmp     word ptr ds:[0], 0xAA55
        jne     3f
        mov     al, ds:[2]
        or      al, al
        jz      3f
        xor     ah, ah
        mov     cl, 9
        shl     ax, cl
        mov     cx, ax
        xor     si, si
        xor     ah, ah
2:      add     ah, ds:[si]             # checksum moet 0 zijn
        inc     si
        loop    2b
        or      ah, ah
        jnz     3f
        push    dx
        push    bx
        mov     ax, BDA
        mov     es, ax
        mov     word ptr es:[ROMINIT], 3
        mov     es:[ROMINIT+2], dx
        .byte   0x26, 0xFF, 0x1E        # call far es:[ROMINIT]
        .word   ROMINIT
        pop     bx
        pop     dx
        mov     ds, dx
        mov     al, ds:[2]
        xor     ah, ah
        mov     cl, 5
        shl     ax, cl
        add     ax, 0x7F
        and     ax, 0xFF80
        add     dx, ax
        jmp     4f
3:      add     dx, 0x80
4:      cmp     dx, bx
        jb      1b
        ret

# print_str: druk ASCIIZ-string af op CS:SI via INT 10h/0Eh
print_str:
        push    ax
        push    bx
        push    si
        mov     bx, 0x0007
1:      mov     al, cs:[si]
        inc     si
        or      al, al
        jz      2f
        mov     ah, 0x0E
        int     0x10
        jmp     1b
2:      pop     si
        pop     bx
        pop     ax
        ret

# print_dec: druk AX decimaal af
print_dec:
        push    ax
        push    bx
        push    cx
        push    dx
        xor     cx, cx
        mov     bx, 10
1:      xor     dx, dx
        div     bx
        push    dx
        inc     cx
        or      ax, ax
        jnz     1b
        mov     bx, 0x0007
2:      pop     ax
        add     al, '0'
        mov     ah, 0x0E
        int     0x10
        loop    2b
        pop     dx
        pop     cx
        pop     bx
        pop     ax
        ret

# wait_ticks: wacht CX timer-ticks (55 ms), DS = BDA
wait_ticks:
        push    ax
        push    dx
        sti
        mov     ax, [TIMER_LO]
1:      mov     dx, [TIMER_LO]
        sub     dx, ax
        cmp     dx, cx
        jb      1b
        pop     dx
        pop     ax
        ret

msg_banner:
        .ascii  "\r\n"
        BIOS_NAME
        .ascii  "\r\n\0"
msg_kb: .ascii  " KB OK\r\n\0"
msg_memtest:
        .ascii  "\rMemory test: \0"
msg_warm:
        .ascii  " KB (warm start)\r\n\0"
msg_ramerr:
        .ascii  "\r\nRAM error at \0"
msg_noboot:
        .ascii  "No bootable disk - retrying...\r\n\0"
msg_parity:
        .ascii  "\r\nPARITY CHECK - SYSTEM HALTED\0"

#--- v0.4: POST-hulproutines -------------------------------------------------
# detect_fpu: 8087 aanwezig? -> equipment bit 1 (DS = BDA, stack nodig)
detect_fpu:
        and     byte ptr [EQUIP], 0xFD
        push    ax                      # werkwoord op de stack
        mov     bp, sp
        .byte   0xDB, 0xE3              # fninit
        mov     cx, 32
1:      loop    1b
        mov     word ptr [bp], 0x5A5A
        .byte   0xDD, 0x7E, 0x00        # fnstsw [bp]
        mov     cx, 32
2:      loop    2b
        cmp     byte ptr [bp], 0        # statuswoord na fninit = 0
        jne     3f
        .byte   0xD9, 0x7E, 0x00        # fnstcw [bp]
        mov     cx, 32
4:      loop    4b
        mov     ax, [bp]
        and     ax, 0x103F
        cmp     ax, 0x003F              # controlewoord na fninit = 037Fh
        jne     3f
        or      byte ptr [EQUIP], 0x02
3:      pop     ax
        ret

# check_video: geen CGA/MDA en INT 10h niet door een option-ROM overgenomen
#   -> 1 lange en 2 korte piepen (DS = BDA, IF = 1)
check_video:
        test    byte ptr [EQUIP], 0x30
        jnz     2f
        xor     ax, ax
        mov     es, ax
        cmp     word ptr es:[0x10*4+2], 0xF000
        jne     2f
        mov     cx, 9
        call    beep
        mov     bl, 2
1:      mov     cx, 4
        call    wait_ticks
        mov     cx, 3
        call    beep
        dec     bl
        jnz     1b
2:      ret

#=============================================================================
AT 0xE2C3                               # vaste entry: NMI (INT 02h)
nmi_int:
        push    ax
        in      al, 0x62
        test    al, 0xC0                # pariteits- of I/O-kanaalfout?
        jz      1f
        mov     si, offset msg_parity
        call    print_str
        cli
9:      hlt
        jmp     9b
1:      pop     ax
        iret

#--- POST --------------------------------------------------------------------
post_start:
        cli
        cld
        xor     al, al
        out     0xA0, al                # NMI uit
        mov     dx, 0x3D8
        out     dx, al                  # CGA-beeld uit
        mov     dx, 0x3B8
        mov     al, 0x01
        out     dx, al                  # MDA-beeld uit
        POSTCODE 0x01

# 1. CPU: flags en registers
        mov     ah, 0xD5
        sahf
        jnc     cpu_fail
        jnz     cpu_fail
        jnp     cpu_fail
        jns     cpu_fail
        lahf
        mov     cl, 5
        shr     ah, cl
        jnc     cpu_fail
        xor     ah, ah
        sahf
        jc      cpu_fail
        jz      cpu_fail
        js      cpu_fail
        jp      cpu_fail

        mov     ax, 0xFFFF
        stc
1:      mov     ds, ax
        mov     bx, ds
        mov     es, bx
        mov     cx, es
        mov     ss, cx
        mov     dx, ss
        mov     sp, dx
        mov     bp, sp
        mov     si, bp
        mov     di, si
        jnc     2f
        xor     ax, di
        jnz     cpu_fail
        jmp     1b
2:      or      di, di
        jnz     cpu_fail
        POSTCODE 0x02

# 2. 8255 PPI: A=in, B=uit, C=in. Toetsenbordklok laag = toetsenbord in reset
#    (blijft laag tot stap 11, ruim langer dan de benodigde 20 ms)
        mov     al, 0x99
        out     0x63, al
        mov     al, 0xB0                # PB7 kbd clear, PB5/4 checks uit, PB6=0
        out     0x61, al

# 3. ROM-checksum
        mov     ax, cs
        mov     ds, ax
        mov     si, 0xE000
        mov     cx, 0x2000
        xor     bl, bl
3:      lodsb
        add     bl, al
        loop    3b
        or      bl, bl
        jnz     rom_fail
        POSTCODE 0x03

# 4. DRAM-refresh: PIT kanaal 1 + DMA kanaal 0; PIT kanaal 0 = 18,2 Hz
        mov     al, 0x54
        out     0x43, al
        mov     al, 18
        out     0x41, al
        xor     al, al
        out     0x0D, al
        out     0x08, al
        out     0x00, al
        out     0x00, al
        mov     al, 0xFF
        out     0x01, al
        out     0x01, al
        mov     al, 0x58
        out     0x0B, al
        mov     al, 0x41
        out     0x0B, al
        mov     al, 0x42
        out     0x0B, al
        mov     al, 0x43
        out     0x0B, al
        xor     al, al
        out     0x0A, al
        mov     al, 0x36
        out     0x43, al
        xor     al, al
        out     0x40, al
        out     0x40, al
        xor     cx, cx
4:      loop    4b
        POSTCODE 0x04

# 5. Eerste 16 KB RAM testen (nog zonder stack). Warme start: alleen wissen
#    (BP bewaart de warme-startvlag, want het wissen raakt ook de BDA)
        xor     ax, ax
        mov     ds, ax
        mov     es, ax
        mov     bp, ds:[0x400+RESET_FLAG]
        cmp     bp, 0x1234
        je      5f
        mov     ax, 0xAA55
        xor     di, di
        mov     cx, 0x2000
        rep     stosw
        xor     di, di
        mov     cx, 0x2000
        repe    scasw
        jne     ram_fail
        mov     ax, 0x55AA
        xor     di, di
        mov     cx, 0x2000
        rep     stosw
        xor     di, di
        mov     cx, 0x2000
        repe    scasw
        jne     ram_fail
5:      xor     ax, ax
        xor     di, di
        mov     cx, 0x2000
        rep     stosw
        mov     ds:[0x400+RESET_FLAG], bp
        mov     ax, 0x0030
        mov     ss, ax
        mov     sp, 0x0100
        POSTCODE 0x05

# 6. 8259 PIC: edge, single, ICW4; vectoren 08-0F; IRQ0 en IRQ6 vrij
        mov     al, 0x13
        out     0x20, al
        mov     al, 0x08
        out     0x21, al
        mov     al, 0x09
        out     0x21, al
        mov     al, 0xBE
        out     0x21, al

# 7. Interruptvectoren, BIOS Data Area, equipment, 8087, COM/LPT
        call    init_vectors
        mov     ax, BDA
        mov     ds, ax
        mov     ax, KB_BUF
        mov     [KB_HEAD], ax
        mov     [KB_TAIL], ax
        mov     [KB_START], ax
        mov     word ptr [KB_END], KB_BUF + 32
        call    read_switches
        and     al, 0xCD                # video en 8087 zelf detecteren
        or      al, 0x01
        push    ax
        call    detect_video
        pop     bx
        or      bl, ah
        xor     bh, bh
        mov     [EQUIP], bx
        call    detect_fpu
        call    detect_ports
        POSTCODE 0x06
        sti

# 8. Video (CGA/MDA) en video-option-ROMs (C000-C7FF), banner
        mov     ax, 0x0003              # ook zonder CGA/MDA: BDA-videovelden
        int     0x10                    # geldig maken (EGA/VGA-ROM overschrijft)
        mov     dx, 0xC000
        mov     bx, 0xC800
        call    rom_scan
        mov     ax, BDA
        mov     ds, ax
        POSTCODE 0x07
        call    check_video             # geen video: 1 lange, 2 korte piepen
        mov     si, offset msg_banner
        call    print_str

# 9. Geheugentest per 16 KB tot 640 KB (zichtbaar). Warme start: geen
#    patroontest, maar wel opnieuw tellen en alles wissen, zodat option-ROMs
#    (XT-IDE) hetzelfde geheugen zien als na een koude start
        mov     bx, 0x0400
3:      mov     ax, bx
        mov     cl, 6
        shr     ax, cl
        call    show_mem
        cmp     bx, 0xA000
        jae     6f
        mov     es, bx
        mov     ax, 0xAA55
        xor     di, di
        cmp     word ptr [RESET_FLAG], 0x1234
        jne     7f
        mov     es:[di], ax             # warm: alleen aanwezigheid testen
        cmp     es:[di], ax
        jne     6f
        jmp     5f
7:      mov     cx, 0x2000
        rep     stosw
        xor     di, di
        mov     cx, 0x2000
        repe    scasw
        jne     4f
5:      xor     ax, ax
        xor     di, di
        mov     cx, 0x2000
        rep     stosw
        add     bx, 0x0400
        jmp     3b
4:      cmp     di, 2                   # eerste woord fout = einde geheugen
        je      6f
        call    ram_error               # fout midden in blok: adres tonen
6:      mov     ax, bx
        mov     cl, 6
        shr     ax, cl
        mov     [MEMSIZE], ax
        call    show_mem
        mov     si, offset msg_kb
        cmp     word ptr [RESET_FLAG], 0x1234
        jne     8f
        mov     si, offset msg_warm
8:      call    print_str
        POSTCODE 0x08

# 10. Overige option-ROMs (C800-F5FF): XT-IDE, harde schijf, ...
        mov     dx, 0xC800
        mov     bx, 0xF600
        call    rom_scan
        POSTCODE 0x09

# 11. Toetsenbord, configuratie, booten
        mov     ax, BDA
        mov     ds, ax
        call    kbd_post
        POSTCODE 0x0A
        call    show_config
        mov     cx, 2
        call    beep                    # een korte piep: POST geslaagd
        call    bbc_hotkey              # "Press B for BBC BASIC"
        mov     word ptr [RESET_FLAG], 0
        mov     al, 0x80
        out     0xA0, al                # NMI aan (pariteit, 8087)
        POSTCODE 0x0B
        int     0x19

cpu_fail:
        mov     al, 0xE1
        jmp     halt_code
rom_fail:
        mov     al, 0xE2
        jmp     halt_code
ram_fail:
        mov     al, 0xE3
halt_code:                              # AL = E1/E2/E3: 1/2/3 piepjes, herhalend
        out     0x80, al
        cli
        mov     bl, al
        and     bl, 3
        mov     al, 0x99
        out     0x63, al
        mov     al, 0xB6                # PIT kanaal 2: blokgolf ~900 Hz
        out     0x43, al
        mov     al, 0x33
        out     0x42, al
        mov     al, 0x05
        out     0x42, al
1:      mov     bh, bl
2:      mov     al, 0xB3                # luidspreker aan
        out     0x61, al
        mov     dl, 2
        call_free_delay
        mov     al, 0xB0                # uit
        out     0x61, al
        mov     dl, 2
        call_free_delay
        dec     bh
        jnz     2b
        mov     dl, 12                  # pauze
        call_free_delay
        jmp     1b

msg_crlf:
        .ascii  "\r\n\0"

#--- INT 05h: print screen (tekstmodus) naar LPT1 ----------------------------
#   Status in 0050:0000: 01 bezig, 00 klaar, FFh fout
int05_body:
        sti
        push    ax
        push    bx
        push    cx
        push    dx
        push    ds
        mov     ax, 0x50
        mov     ds, ax
        cmp     byte ptr ds:[0], 1
        je      ps_exit
        mov     byte ptr ds:[0], 1
        mov     ah, 0x0F
        int     0x10                    # AH = kolommen, BH = pagina
        push    ax
        mov     ah, 0x03                # (geeft ook CX = cursorvorm)
        int     0x10
        pop     ax
        mov     cl, ah
        push    dx                      # cursor bewaren
        call    ps_crlf
        jc      ps_err
        xor     dh, dh
1:      xor     dl, dl
2:      mov     ah, 0x02
        int     0x10
        mov     ah, 0x08
        int     0x10
        or      al, al
        jnz     3f
        mov     al, ' '
3:      call    ps_char
        jc      ps_err
        inc     dl
        cmp     dl, cl
        jb      2b
        call    ps_crlf
        jc      ps_err
        inc     dh
        cmp     dh, 25
        jb      1b
        mov     byte ptr ds:[0], 0
        jmp     4f
ps_err: mov     byte ptr ds:[0], 0xFF
4:      pop     dx
        mov     ah, 0x02
        int     0x10
ps_exit:
        pop     ds
        pop     dx
        pop     cx
        pop     bx
        pop     ax
        iret

ps_crlf:
        mov     al, 0x0D
        call    ps_char
        jc      1f
        mov     al, 0x0A
        call    ps_char
1:      ret

ps_char:                                # AL naar LPT1, CF=1 bij fout
        push    dx
        xor     dx, dx
        xor     ah, ah
        int     0x17
        pop     dx
        test    ah, 0x29                # time-out, I/O-fout, papier op
        jz      1f
        stc
        ret
1:      clc
        ret

#--- INT 10h grafisch: teken lezen (AH=08) door patroon met font te vergelijken
g_read:
        call    g_cellpos
        sub     sp, 8
        mov     bx, sp
        mov     dh, 4
1:      call    g_getrow
        mov     ss:[bx], al
        add     di, 0x2000
        call    g_getrow
        mov     ss:[bx+1], al
        sub     di, 0x2000 - 80
        add     bx, 2
        dec     dh
        jnz     1b
        push    ss
        pop     es
        push    cs
        pop     ds
        mov     si, offset font_8x8
        xor     ax, ax                  # AL = teken, AH = 1 bij INT 1Fh-deel
        mov     dx, 128
2:      mov     di, sp
        mov     cx, 8
        push    si
        repe    cmpsb
        pop     si
        je      4f
        add     si, 8
        inc     al
        dec     dx
        jnz     2b
        or      ah, ah
        jnz     3f
        xor     si, si
        mov     ds, si
        lds     si, ds:[0x1F*4]
        mov     cx, ds
        or      cx, si
        jz      3f                      # geen tekens 80h-FFh geïnstalleerd
        mov     ah, 1
        mov     dx, 128
        jmp     2b
3:      xor     al, al
4:      mov     [bp+16], al             # (BP-adressering gebruikt SS)
        mov     byte ptr [bp+17], 0
        add     sp, 8
        ret

# g_getrow: ES:DI -> AL = 8 pixels als bits (pixel <> 0 = 1)
g_getrow:
        mov     al, es:[di]
        cmp     dl, 6
        je      3f
        push    cx
        push    dx
        mov     ah, es:[di]
        mov     al, es:[di+1]
        mov     cx, 8
        xor     dh, dh
1:      shl     dh, 1
        test    ah, 0xC0
        jz      2f
        or      dh, 1
2:      shl     ax, 1
        shl     ax, 1
        loop    1b
        mov     al, dh
        pop     dx
        pop     cx
3:      ret

#--- v0.4: INT 19h bootstrap: A: en daarna C: --------------------------------
int19_body:
        sti
        mov     cx, 4                   # A: maximaal 4 pogingen
1:      push    cx
        xor     ax, ax
        xor     dx, dx
        int     0x13
        mov     ax, 0x0201
        xor     dx, dx
        mov     es, dx
        mov     bx, 0x7C00
        mov     cx, 0x0001
        int     0x13
        pop     cx
        jnc     3f
        cmp     ah, 0x80                # time-out: geen diskette, niet herhalen
        je      2f
        loop    1b
2:      mov     ax, BDA                 # C: alleen als een option-ROM
        mov     ds, ax                  # harde schijven heeft gemeld
        cmp     byte ptr ds:[0x75], 0
        je      4f
        xor     ax, ax
        mov     dx, 0x0080
        int     0x13
        mov     ax, 0x0201
        mov     dx, 0x0080
        xor     bx, bx
        mov     es, bx
        mov     bx, 0x7C00
        mov     cx, 0x0001
        int     0x13
        jc      4f
        cmp     word ptr es:[0x7DFE], 0xAA55
        jne     4f
        mov     dl, 0x80
        jmp     5f
3:      xor     dx, dx
5:      xor     dh, dh
        .byte   0xEA                    # jmp far 0000:7C00, DL = station
        .word   0x7C00, 0x0000
4:      int     0x18

#=============================================================================
AT 0xE6F2                               # vaste entry: INT 19h bootstrap
int19:
        jmp     int19_body

# show_mem: "\\rMemory test: <AX>" (geen nieuwe regel)
show_mem:
        mov     si, offset msg_memtest
        call    print_str
        jmp     print_dec

# ram_error: "RAM error at SSSS:OOOO" voor ES:DI-2
ram_error:
        mov     si, offset msg_ramerr
        call    print_str
        mov     ax, es
        call    print_hex4
        mov     al, ':'
        call    print_char
        lea     ax, [di-2]
        call    print_hex4
        mov     si, offset msg_crlf
        jmp     print_str

#=============================================================================
AT 0xE729                               # baud-rate delers (1,8432 MHz / 16)
baud_table:
        .word   1047, 768, 384, 192, 96, 48, 24, 12

AT 0xE739                               # vaste entry: INT 14h serieel
int14:
        jmp     int14_body

# beep: toon van CX ticks via PIT kanaal 2 (DS = BDA, IF=1)
beep:
        push    ax
        mov     al, 0xB6
        out     0x43, al
        mov     ax, 1331                # ~896 Hz
        out     0x42, al
        mov     al, ah
        out     0x42, al
        in      al, 0x61
        push    ax
        or      al, 0x03
        out     0x61, al
        call    wait_ticks
        pop     ax
        out     0x61, al
        pop     ax
        ret

# kbd_post: toetsenbordklok loslaten, wachten op AAh (zelftest OK)
kbd_post:
        mov     al, 0x48                # PB6=1 klok aan, PB7=0 data vrij
        out     0x61, al
        mov     bx, [TIMER_LO]
1:      mov     al, 0x0A                # OCW3: IRR lezen
        out     0x20, al
        in      al, 0x20
        test    al, 0x02                # IRQ1 aangevraagd (gemaskeerd)?
        jnz     2f
        mov     ax, [TIMER_LO]
        sub     ax, bx
        cmp     ax, 19                  # ~1 seconde
        jb      1b
        jmp     3f
2:      in      al, 0x60
        mov     ah, al
        call    kbd_ack
        cmp     ah, 0xAA
        je      4f
        jmp     1b                      # ander byte (bv. losgelaten toets): verder wachten
3:      mov     si, offset msg_kberr
        call    print_str
4:      mov     ax, [KB_START]
        mov     [KB_HEAD], ax
        mov     [KB_TAIL], ax
        in      al, 0x21
        and     al, 0xFD                # IRQ1 vrijgeven
        out     0x21, al
        ret

# kbd_ack: PB7 kort hoog = scancode bevestigen, schuifregister leeg
kbd_ack:
        in      al, 0x61
        or      al, 0x80
        out     0x61, al
        and     al, 0x7F
        out     0x61, al
        ret

msg_kberr:
        .ascii  "Keyboard error\r\n\0"

#--- v0.4: INT 10h AH=13h string schrijven ----------------------------------
#   AL bit0: cursor bijwerken, bit1: string bevat teken/attribuut-paren
#   BH pagina, BL attribuut, CX lengte, DH/DL positie, ES:BP string
#   (tekens worden geschreven met AH=09 en doorgeschoven met AH=0Eh,
#    dus regelomloop en scrollen gelden voor de actieve pagina)
v_wstring:
        mov     si, [bp+4]              # BP van de aanroeper
        mov     di, ax                  # DI: modusbits
        mov     ah, 0x03
        int     0x10                    # DX = cursor pagina BH
        push    dx
        mov     dx, [bp+10]
        mov     ah, 0x02
        int     0x10
        mov     cx, [bp+12]
        jcxz    4f
1:      mov     al, es:[si]
        inc     si
        test    di, 2
        jz      2f
        mov     bl, es:[si]
        inc     si
2:      cmp     al, 0x0D
        je      3f
        cmp     al, 0x0A
        je      3f
        cmp     al, 0x08
        je      3f
        cmp     al, 0x07
        je      3f
        push    cx
        mov     cx, 1
        mov     ah, 0x09
        int     0x10
        pop     cx
3:      mov     ah, 0x0E
        int     0x10
        loop    1b
4:      pop     dx
        test    di, 1
        jnz     5f
        mov     ah, 0x02
        int     0x10
5:      ret

# bbc_present: ZF=1 als er een BBC BASIC-ROM op F600:0000 staat ("BBCROM")
bbc_present:
        push    ds
        push    ax
        mov     ax, 0xF600
        mov     ds, ax
        cmp     word ptr ds:[2], 0x4242 # "BB"
        jne     1f
        cmp     word ptr ds:[4], 0x5243 # "CR"
1:      pop     ax
        pop     ds
        ret

#=============================================================================
AT 0xE82E                               # vaste entry: INT 16h toetsenbord
int16:
        sti
        push    ds
        push    bx
        mov     bx, BDA
        mov     ds, bx
        or      ah, ah
        jz      k16_read
        cmp     ah, 1
        je      k16_peek
        cmp     ah, 2
        jne     k16_done
        mov     al, [KB_FLAG]           # AH=02: shift-status
k16_done:
        pop     bx
        pop     ds
        iret

k16_read:                               # AH=00: wachten op toets
        cli
        mov     bx, [KB_HEAD]
        cmp     bx, [KB_TAIL]
        jne     1f
        sti
        hlt                             # slapen tot volgende interrupt
        jmp     k16_read
1:      mov     ax, [bx]
        add     bx, 2
        cmp     bx, [KB_END]
        jb      2f
        mov     bx, [KB_START]
2:      mov     [KB_HEAD], bx
        jmp     k16_done

k16_peek:                               # AH=01: ZF=1 als buffer leeg
        cli
        mov     bx, [KB_HEAD]
        cmp     bx, [KB_TAIL]
        je      1f
        mov     ax, [bx]
1:      sti
        pop     bx
        pop     ds
        retf    2

#--- INT 10h hulproutines (DS = BDA) -----------------------------------------
vid_seg_es:
        push    ax
        mov     ax, 0xB800
        cmp     byte ptr [VMODE], 7
        jne     1f
        mov     ax, 0xB000
1:      mov     es, ax
        pop     ax
        ret

calc_offset:                            # DH=rij DL=kolom -> DI (sloopt AX)
        mov     al, dh
        mul     byte ptr [VCOLS]
        add     al, dl
        adc     ah, 0
        shl     ax, 1
        add     ax, [VSTART]
        mov     di, ax
        ret

cursor_di:                              # ES:DI = cursorpositie op pagina BH
        call    vid_seg_es              # (sloopt AX, BX, DX)
        mov     bl, bh
        and     bx, 7                   # BX = pagina 0-7
        mov     al, bl
        xor     ah, ah
        mul     word ptr [VPAGESZ]      # AX = begin van pagina BH
        mov     di, ax
        shl     bx, 1
        mov     dx, [bx+VCURPOS]        # cursor van pagina BH
        mov     al, dh
        mul     byte ptr [VCOLS]
        add     al, dl
        adc     ah, 0
        shl     ax, 1
        add     di, ax
        ret

update_cursor:
        push    ax
        push    bx
        push    dx
        mov     bl, [VPAGE]
        xor     bh, bh
        shl     bx, 1
        mov     dx, [bx+VCURPOS]
        mov     al, dh
        mul     byte ptr [VCOLS]
        add     al, dl
        adc     ah, 0
        mov     bx, [VSTART]
        shr     bx, 1
        add     bx, ax
        mov     dx, [VCRTC]
        mov     al, 0x0E
        out     dx, al
        inc     dx
        mov     al, bh
        out     dx, al
        dec     dx
        mov     al, 0x0F
        out     dx, al
        inc     dx
        mov     al, bl
        out     dx, al
        pop     dx
        pop     bx
        pop     ax
        ret

set_ctype_hw:
        mov     dx, [VCRTC]
        mov     al, 0x0A
        out     dx, al
        inc     dx
        mov     al, ch
        out     dx, al
        dec     dx
        mov     al, 0x0B
        out     dx, al
        inc     dx
        mov     al, cl
        out     dx, al
        ret

# bbc_hotkey: ~1,5 s wachten op B -> BBC BASIC (DS = BDA, IF = 1)
bbc_hotkey:
        call    bbc_present
        jne     3f
        mov     si, offset msg_bkey
        call    print_str
        mov     bx, [TIMER_LO]
1:      mov     ah, 1
        int     0x16
        jz      2f
        xor     ah, ah
        int     0x16
        or      al, 0x20
        cmp     al, 'b'
        jne     2f
        int     0x18
2:      mov     ax, [TIMER_LO]
        sub     ax, bx
        cmp     ax, 27
        jb      1b
        mov     si, offset msg_bclr
        call    print_str
3:      ret

msg_bkey: .ascii "Press B for BBC BASIC\0"
msg_bclr: .ascii "\r                     \r\0"

#=============================================================================
AT 0xE987                               # vaste entry: INT 09h (IRQ1)
int09:
        jmp     int09_body

#--- INT 10h ------------------------------------------------------------------
int10_body:
        sti
        cld
        push    ax
        push    bx
        push    cx
        push    dx
        push    si
        push    di
        push    bp
        push    ds
        push    es
        mov     bp, sp                  # [bp+16]=AX [bp+14]=BX
        mov     si, BDA                 # [bp+12]=CX [bp+10]=DX
        mov     ds, si
        cmp     ah, 0x13
        ja      1f
        push    ax
        mov     al, ah
        xor     ah, ah
        shl     ax, 1
        mov     si, ax
        pop     ax
        call    word ptr cs:[si+int10_table]
1:      pop     es
        pop     ds
        pop     bp
        pop     di
        pop     si
        pop     dx
        pop     cx
        pop     bx
        pop     ax
        iret

int10_table:
        .word   v_set_mode, v_set_ctype, v_set_cursor, v_get_cursor
        .word   v_lpen, v_set_page, v_scroll, v_scroll
        .word   v_read_ca, v_write_ca, v_write_c, v_palette
        .word   v_wpixel, v_rpixel, v_tty, v_get_mode
        .word   v_nop, v_nop, v_nop, v_wstring

# AH=00: videomode instellen
v_set_mode:
        and     al, 0x7F
        mov     ah, [EQUIP]
        and     ah, 0x30
        mov     dx, 0x3B4
        cmp     ah, 0x30
        jne     1f
        mov     al, 7
        jmp     2f
1:      mov     dx, 0x3D4
        cmp     al, 7
        jb      2f
        mov     al, 3
2:      mov     [VMODE], al
        mov     [VCRTC], dx
        mov     bl, al
        xor     bh, bh
        mov     al, cs:[bx+vid_modectl]
        mov     [VMODEREG], al
        push    dx
        add     dx, 4
        and     al, 0x37
        out     dx, al
        pop     dx
        mov     al, cs:[bx+vid_crtsel]
        xor     ah, ah
        add     ax, offset video_params
        mov     si, ax
        xor     ah, ah
3:      mov     al, ah
        out     dx, al
        inc     dx
        mov     al, cs:[si]
        inc     si
        out     dx, al
        dec     dx
        inc     ah
        cmp     ah, 16
        jb      3b
        mov     al, cs:[bx+vid_cols]
        xor     ah, ah
        mov     [VCOLS], ax
        shl     bx, 1
        mov     ax, cs:[bx+vid_pagesz]
        mov     [VPAGESZ], ax
        xor     ax, ax
        mov     [VSTART], ax
        mov     [VPAGE], al
        push    ds
        pop     es
        mov     di, VCURPOS
        mov     cx, 8
        rep     stosw
        mov     ax, 0x0607
        cmp     byte ptr [VMODE], 7
        jne     4f
        mov     ax, 0x0B0C
4:      mov     [VCURTYPE], ax
        call    vid_seg_es
        xor     di, di
        mov     cx, 0x2000
        mov     ax, 0x0720
        cmp     byte ptr [VMODE], 7
        je      5f
        cmp     byte ptr [VMODE], 4
        jb      6f
        xor     ax, ax
        jmp     6f
5:      mov     cx, 0x0800
6:      rep     stosw
        mov     dx, [VCRTC]
        add     dx, 4
        mov     al, [VMODEREG]
        out     dx, al
        inc     dx
        mov     al, 0x30
        cmp     byte ptr [VMODE], 6
        jne     7f
        mov     al, 0x3F
7:      mov     [VPAL], al
        cmp     byte ptr [VMODE], 7
        je      8f
        out     dx, al
8:      mov     cx, [VCURTYPE]
        call    set_ctype_hw
        jmp     update_cursor

v_set_ctype:
        mov     [VCURTYPE], cx
        jmp     set_ctype_hw

v_set_cursor:
        mov     bl, bh
        and     bl, 7
        xor     bh, bh
        shl     bx, 1
        mov     [bx+VCURPOS], dx
        shr     bx, 1
        cmp     bl, [VPAGE]
        jne     v_nop
        jmp     update_cursor

v_get_cursor:
        mov     bl, bh
        and     bl, 7
        xor     bh, bh
        shl     bx, 1
        mov     ax, [bx+VCURPOS]
        mov     [bp+10], ax
        mov     ax, [VCURTYPE]
        mov     [bp+12], ax
v_nop:  ret

#--- INT 10h grafisch: tekens schrijven (modi 4/5/6) -------------------------
# g_cellpos: cursor (pagina 0) -> ES:DI = linksboven van tekencel, DL = mode
g_cellpos:
        mov     dx, [VCURPOS]
        call    vid_seg_es
        mov     ah, dh                  # rij * 320 = rij*256 + rij*64
        xor     al, al
        mov     di, ax
        shr     ax, 1
        shr     ax, 1
        add     di, ax
        mov     al, dl
        xor     ah, ah
        mov     dl, [VMODE]
        cmp     dl, 6
        je      1f
        shl     ax, 1                   # 320x200: 2 bytes per tekencel
1:      add     di, ax
        ret

# g_write: AL = teken, BL = kleur (bit7: XOR), CX = aantal; DS = BDA
g_write:
        jcxz    9f
        push    ds
        push    bp
        mov     ah, bl
        mov     bp, ax                  # BP = kleur:teken
        call    g_cellpos
        mov     ax, bp
        mov     bl, al                  # glyph-adres = teken * 8
        xor     bh, bh
        shl     bx, 1
        shl     bx, 1
        shl     bx, 1
        test    al, 0x80
        jnz     2f
        add     bx, offset font_8x8
        mov     si, bx
        push    cs
        pop     ds
        jmp     3f
2:      and     bx, 0x03FF              # tekens 80h-FFh via INT 1Fh-vector
        xor     si, si
        mov     ds, si
        lds     si, ds:[0x1F*4]
        add     si, bx
3:      mov     ax, bp                  # AH = kleur
        mov     al, ah
        and     al, 3
        mov     bl, 0x55                # 320x200: kleur in elk bitpaar
        cmp     dl, 6
        jne     4f
        and     al, 1
        mov     bl, 0xFF                # 640x200: alle bits
4:      mul     bl                      # AL = masker
        mov     bx, bp
        mov     ah, bh
        mov     bp, ax                  # BP = kleur : masker
5:      push    cx
        push    si
        push    di
        mov     dh, 4                   # 4 paren scanlines (even/oneven bank)
6:      call    g_row
        add     di, 0x2000
        call    g_row
        sub     di, 0x2000 - 80
        dec     dh
        jnz     6b
        pop     di
        pop     si
        pop     cx
        inc     di
        cmp     dl, 6
        je      7f
        inc     di
7:      loop    5b
        pop     bp
        pop     ds
9:      ret

# g_row: volgende glyph-byte (DS:SI) naar ES:DI; BP = kleur:masker, DL = mode
g_row:
        lodsb
        cmp     dl, 6
        je      3f
        push    cx                      # 320x200: elke bit verdubbelen
        mov     cx, 8
        xor     bx, bx
1:      shl     bx, 1
        shl     bx, 1
        shl     al, 1
        jnc     2f
        or      bl, 3
2:      loop    1b
        pop     cx
        mov     ax, bp
        and     bl, al
        and     bh, al
        test    ah, 0x80
        jnz     4f
        mov     es:[di], bh
        mov     es:[di+1], bl
        ret
4:      xor     es:[di], bh
        xor     es:[di+1], bl
        ret
3:      mov     bx, bp                  # 640x200: 1 bit per pixel
        and     al, bl
        test    bh, 0x80
        jnz     5f
        mov     es:[di], al
        ret
5:      xor     es:[di], al
        ret

# v0.4: teksten configuratieoverzicht
msg_cpu:  .ascii "CPU: \0"
msg_8088: .ascii "8088\0"
msg_v20:  .ascii "NEC V20\0"
msg_fpu:  .ascii "   FPU: \0"
msg_8087: .ascii "8087\0"
msg_none1: .ascii " "
msg_none: .ascii "none\0"
msg_flp:  .ascii "   Floppy: \0"
msg_hdd:  .ascii "   Hard disk: \0"
msg_com:  .ascii "\r\nCOM:\0"
msg_lpt:  .ascii "   LPT:\0"

#=============================================================================
AT 0xEC59                               # vaste entry: INT 13h diskette
int13:
        sti
        cld
        push    bx
        push    cx
        push    dx
        push    si
        push    di
        push    bp
        push    ds
        push    es
        mov     si, BDA
        mov     ds, si
        cmp     dl, 3
        ja      d_bad
        or      ah, ah
        jz      d_reset
        cmp     ah, 1
        je      d_status
        cmp     ah, 5
        ja      d_bad
        cmp     ah, 2
        jae     d_rw
d_bad:  mov     ah, 0x01
        jmp     d_ret
d_reset:
        call    fdc_reset
        mov     ah, [DISK_ST]
        jmp     d_ret
d_status:
        mov     ah, [DISK_ST]
        mov     al, ah
        jmp     d_ret
d_rw:   mov     byte ptr [DISK_ST], 0
        mov     bp, ax
        call    motor_on
        call    seek
        jc      1f
        call    dma_setup
        jc      1f
        call    fdc_rw
        jc      1f
        mov     ax, bp
        xor     ah, ah
        jmp     2f
1:      mov     ah, [DISK_ST]
        xor     al, al
        and     byte ptr [SEEK_ST], 0xF0
2:      push    ax
        mov     al, 2
        call    get_parm
        mov     [MOTOR_CNT], al
        pop     ax
d_ret:  mov     [DISK_ST], ah
        cmp     ah, 1
        cmc
        pop     es
        pop     ds
        pop     bp
        pop     di
        pop     si
        pop     dx
        pop     cx
        pop     bx
        retf    2

get_parm:
        push    ds
        push    si
        push    bx
        xor     si, si
        mov     ds, si
        lds     si, ds:[0x1E*4]
        mov     bl, al
        xor     bh, bh
        mov     al, [si+bx]
        pop     bx
        pop     si
        pop     ds
        ret

motor_on:
        push    ax
        push    cx
        push    dx
        mov     byte ptr [MOTOR_CNT], 0xFF
        mov     cl, dl
        mov     al, 1
        shl     al, cl
        mov     ah, [MOTOR_ST]
        cli
        mov     [MOTOR_ST], al
        mov     ch, al
        mov     cl, 4
        shl     al, cl
        or      al, dl
        or      al, 0x0C
        mov     dx, 0x3F2
        out     dx, al
        sti
        test    ah, ch
        jnz     1f
        mov     al, 10
        call    get_parm
        xor     ah, ah
        mov     cx, ax
        shl     cx, 1
        add     cx, ax
        call    wait_ticks
1:      pop     dx
        pop     cx
        pop     ax
        ret

fdc_out:
        push    cx
        push    dx
        push    ax
        mov     ah, al
        mov     dx, 0x3F4
        xor     cx, cx
1:      in      al, dx
        and     al, 0xC0
        cmp     al, 0x80
        je      2f
        loop    1b
        pop     ax
        mov     byte ptr [DISK_ST], 0x80
        stc
        jmp     3f
2:      inc     dx
        mov     al, ah
        out     dx, al
        pop     ax
        clc
3:      pop     dx
        pop     cx
        ret

fdc_in:
        push    cx
        push    dx
        mov     dx, 0x3F4
        xor     cx, cx
1:      in      al, dx
        and     al, 0xC0
        cmp     al, 0xC0
        je      2f
        loop    1b
        mov     byte ptr [DISK_ST], 0x80
        stc
        jmp     3f
2:      inc     dx
        in      al, dx
        clc
3:      pop     dx
        pop     cx
        ret

fdc_results:
        push    ax
        push    cx
        push    dx
        push    di
        mov     di, FDC_RES
        mov     cx, 7
1:      call    fdc_in
        jc      3f
        mov     [di], al
        inc     di
        push    cx
        mov     cx, 10
2:      loop    2b
        pop     cx
        mov     dx, 0x3F4
        in      al, dx
        test    al, 0x10
        jz      4f
        loop    1b
3:      mov     byte ptr [DISK_ST], 0x20
        stc
        jmp     5f
4:      clc
5:      pop     di
        pop     dx
        pop     cx
        pop     ax
        ret

wait_irq:
        push    ax
        push    dx
        sti
        mov     ax, [TIMER_LO]
1:      test    byte ptr [SEEK_ST], 0x80
        jnz     2f
        mov     dx, [TIMER_LO]
        sub     dx, ax
        cmp     dx, 37
        jb      1b
        mov     byte ptr [DISK_ST], 0x80
        stc
        jmp     3f
2:      and     byte ptr [SEEK_ST], 0x7F
        clc
3:      pop     dx
        pop     ax
        ret

sense_int:
        mov     al, 0x08
        call    fdc_out
        jc      1f
        call    fdc_results
1:      ret

#--- INT 10h grafisch: venster scrollen (AH=06/07 in modi 4/5/6) ------------
#   Per tekenrij 4 scanlines in elke bank; elke bank apart verschuiven.
g_scroll:
        push    ds
        push    bp
        mov     bl, dh
        sub     bl, ch
        inc     bl                      # BL = rijen in venster
        sub     dl, cl
        inc     dl                      # DL = breedte in tekens
        or      al, al
        jz      1f
        cmp     al, bl
        jbe     2f
1:      mov     al, bl
2:      push    ax                      # AL = regels, AH = richting
        mov     al, bh                  # vulbyte uit kleur BH
        and     al, 3
        mov     ah, 0x55
        cmp     byte ptr [VMODE], 6
        jne     3f
        and     al, 1
        mov     ah, 0xFF
        jmp     4f
3:      shl     dl, 1                   # 320x200: 2 bytes per teken
        shl     cl, 1
4:      mul     ah
        mov     bh, al                  # BH = vulbyte
        pop     ax
        push    ax
        mov     bp, 80                  # omhoog: begin bovenaan
        mov     al, ch
        cmp     ah, 7
        jne     5f
        mov     al, dh                  # omlaag: begin op laatste scanline
        neg     bp
5:      xor     ah, ah
        shl     ax, 1
        shl     ax, 1                   # bankregel = tekenrij * 4
        or      bp, bp
        jns     6f
        add     ax, 3
6:      shl     ax, 1                   # * 80 = *16 + *64
        shl     ax, 1
        shl     ax, 1
        shl     ax, 1
        mov     di, ax
        shl     ax, 1
        shl     ax, 1
        add     di, ax
        mov     al, cl
        xor     ah, ah
        add     di, ax
        pop     ax
        sub     bl, al                  # BL = te verplaatsen bankregels
        shl     bl, 1
        shl     bl, 1
        mov     dh, al                  # DH = leeg te maken bankregels
        shl     dh, 1
        shl     dh, 1
        call    vid_seg_es
        push    es
        pop     ds
        call    g_bank
        add     di, 0x2000
        call    g_bank
        pop     bp
        pop     ds
        ret

# g_bank: DI = startregel, BP = +/-80, DL = breedte, BL = verplaatsen,
#         DH = wissen, BH = vulbyte; DS = ES = videogeheugen
g_bank:
        push    di
        mov     si, di
        mov     cl, dh
        xor     ch, ch
        jcxz    1f
0:      add     si, bp
        loop    0b
1:      mov     ah, bl
2:      or      ah, ah
        jz      3f
        push    si
        push    di
        mov     cl, dl
        rep     movsb
        pop     di
        pop     si
        add     si, bp
        add     di, bp
        dec     ah
        jmp     2b
3:      mov     ah, dh
        mov     al, bh
4:      or      ah, ah
        jz      5f
        push    di
        mov     cl, dl
        rep     stosb
        pop     di
        add     di, bp
        dec     ah
        jmp     4b
5:      pop     di
        ret

#--- v0.4: configuratieoverzicht ---------------------------------------------
# show_config: CPU, FPU, diskettestations, harde schijven, COM, LPT (DS = BDA)
show_config:
        mov     si, offset msg_cpu
        call    print_str
        mov     si, offset msg_8088
        mov     ax, 0x0101
        .byte   0xD5, 0x10              # aad 16: 8088 -> 11h, V20 (altijd 10) -> 0Bh
        cmp     al, 0x11
        je      1f
        mov     si, offset msg_v20
1:      call    print_str
        mov     si, offset msg_fpu
        call    print_str
        mov     si, offset msg_none
        test    byte ptr [EQUIP], 0x02
        jz      2f
        mov     si, offset msg_8087
2:      call    print_str
        mov     si, offset msg_flp
        call    print_str
        mov     al, [EQUIP]
        xor     ah, ah
        test    al, 1
        jz      3f
        mov     cl, 6
        shr     al, cl
        inc     ax
3:      call    print_dec
        mov     si, offset msg_hdd
        call    print_str
        mov     al, [0x75]              # aantal harde schijven (door option-ROM)
        xor     ah, ah
        call    print_dec
        mov     si, offset msg_com
        call    print_str
        mov     di, COM_BASE
        mov     cx, 4
        call    print_ports
        mov     si, offset msg_lpt
        call    print_str
        mov     di, LPT_BASE
        mov     cx, 3
        call    print_ports
        mov     si, offset msg_crlf
        call    print_str
        jmp     print_str               # (msg_crlf eindigt op \0: lege regel)

# print_ports: CX woorden vanaf [DI] als hex, of "none"
print_ports:
        xor     dx, dx
1:      mov     ax, [di]
        or      ax, ax
        jz      2f
        push    ax
        mov     al, ' '
        call    print_char
        pop     ax
        call    print_hex4
        inc     dx
2:      inc     di
        inc     di
        loop    1b
        or      dx, dx
        jnz     3f
        mov     si, offset msg_none1
        call    print_str
3:      ret

#=============================================================================
AT 0xEF57                               # vaste entry: INT 0Eh (IRQ6, FDC)
int0e:
        push    ax
        push    ds
        mov     ax, BDA
        mov     ds, ax
        or      byte ptr [SEEK_ST], 0x80
        mov     al, 0x20
        out     0x20, al
        pop     ds
        pop     ax
        iret

v_set_page:
        and     al, 7
        mov     [VPAGE], al
        xor     ah, ah
        mul     word ptr [VPAGESZ]
        mov     [VSTART], ax
        shr     ax, 1
        mov     bx, ax
        mov     dx, [VCRTC]
        mov     al, 0x0C
        out     dx, al
        inc     dx
        mov     al, bh
        out     dx, al
        dec     dx
        mov     al, 0x0D
        out     dx, al
        inc     dx
        mov     al, bl
        out     dx, al
        jmp     update_cursor

v_get_mode:
        mov     al, [VMODE]
        mov     ah, [VCOLS]
        mov     [bp+16], ax
        mov     al, [VPAGE]
        mov     [bp+15], al
        ret

#=============================================================================
AT 0xEFC7                               # vaste entry: disketteparameters (INT 1Eh)
disk_params:
        .byte   0xDF, 0x02, 0x25, 0x02, 9, 0x2A, 0xFF, 0x50, 0xF6, 15, 4

AT 0xEFD2                               # vaste entry: INT 17h printer
int17:
        jmp     int17_body

# detect_ports: COM- en LPT-poorten zoeken, BDA en equipment vullen (DS=BDA)
detect_ports:
        xor     di, di
        mov     si, offset com_ports
1:      mov     dx, cs:[si]
        or      dx, dx
        jz      3f
        add     dx, 3                   # LCR is volledig terugleesbaar
        mov     al, 0x1A
        out     dx, al
        jmp     2f
2:      in      al, dx
        mov     ah, al
        mov     al, 0x03
        out     dx, al
        sub     dx, 3
        cmp     ah, 0x1A
        jne     4f
        mov     [di+COM_BASE], dx
        add     di, 2
4:      add     si, 2
        jmp     1b
3:      mov     ax, di                  # aantal*2 << 8 = aantal << 9
        mov     ah, al
        xor     al, al
        or      [EQUIP], ax
        xor     di, di
        mov     si, offset lpt_ports
5:      mov     dx, cs:[si]
        or      dx, dx
        jz      7f
        mov     al, 0xAA                # datalatch terugleesbaar
        out     dx, al
        jmp     6f
6:      in      al, dx
        cmp     al, 0xAA
        jne     8f
        mov     [di+LPT_BASE], dx
        add     di, 2
8:      add     si, 2
        jmp     5b
7:      mov     ax, di                  # aantal*2 << 13 = aantal << 14
        mov     cl, 13
        shl     ax, cl
        or      [EQUIP], ax
        mov     word ptr [LPT_TMO], 0x1414
        mov     byte ptr [LPT_TMO+2], 0x14
        mov     word ptr [COM_TMO], 0x0101
        mov     word ptr [COM_TMO+2], 0x0101
        ret

com_ports:  .word 0x3F8, 0x2F8, 0x3E8, 0x2E8, 0
lpt_ports:  .word 0x3BC, 0x378, 0x278, 0

#=============================================================================
AT 0xF065                               # vaste entry: INT 10h
int10:
        jmp     int10_body

# print_char: AL als teletype; print_hex4: AX als 4 hexcijfers
print_char:
        push    ax
        push    bx
        mov     ah, 0x0E
        mov     bx, 0x0007
        int     0x10
        pop     bx
        pop     ax
        ret

print_hex4:
        push    ax
        push    cx
        push    dx
        mov     dx, ax
        mov     ch, 4
1:      mov     cl, 4
        rol     dx, cl
        mov     al, dl
        and     al, 0x0F
        add     al, 0x90                # 0-F -> '0'-'9','A'-'F'
        daa
        adc     al, 0x40
        daa
        call    print_char
        dec     ch
        jnz     1b
        pop     dx
        pop     cx
        pop     ax
        ret

#=============================================================================
AT 0xF0A4                               # vaste entry: 6845-parameters (INT 1Dh)
video_params:
        .byte   0x38,0x28,0x2D,0x0A,0x1F,0x06,0x19,0x1C
        .byte   0x02,0x07,0x06,0x07,0x00,0x00,0x00,0x00
        .byte   0x71,0x50,0x5A,0x0A,0x1F,0x06,0x19,0x1C
        .byte   0x02,0x07,0x06,0x07,0x00,0x00,0x00,0x00
        .byte   0x38,0x28,0x2D,0x0A,0x7F,0x06,0x64,0x70
        .byte   0x02,0x01,0x06,0x07,0x00,0x00,0x00,0x00
        .byte   0x61,0x50,0x52,0x0F,0x19,0x06,0x19,0x19
        .byte   0x02,0x0D,0x0B,0x0C,0x00,0x00,0x00,0x00

vid_pagesz:  .word 0x0800,0x0800,0x1000,0x1000,0x4000,0x4000,0x4000,0x1000
vid_cols:    .byte 40,40,80,80,40,40,80,80
vid_modectl: .byte 0x2C,0x28,0x2D,0x29,0x2A,0x2E,0x1E,0x29
vid_crtsel:  .byte 0,0,16,16,32,32,32,48

# AH=06/07: venster scrollen
v_scroll:
        call    in_gfx
        jc      g_scroll
        push    ds
        push    bp
        call    vid_seg_es
        mov     bl, dh
        sub     bl, ch
        inc     bl
        sub     dl, cl
        inc     dl
        or      al, al
        jz      1f
        cmp     al, bl
        jbe     2f
1:      mov     al, bl
2:      push    ax
        mov     al, [VCOLS]
        xor     ah, ah
        shl     ax, 1
        mov     bp, ax
        pop     ax
        push    ax
        cmp     ah, 7
        jne     3f
        mov     ch, dh
        neg     bp
3:      push    dx
        mov     dx, cx
        call    calc_offset
        pop     dx
        pop     ax
        mov     dh, al
        mov     si, di
        mov     cl, al
        xor     ch, ch
        jcxz    5f
4:      add     si, bp
        loop    4b
5:      sub     bl, dh
        mov     ah, bh
        push    es
        pop     ds
6:      or      bl, bl
        jz      7f
        push    si
        push    di
        mov     cl, dl
        xor     ch, ch
        rep     movsw
        pop     di
        pop     si
        add     si, bp
        add     di, bp
        dec     bl
        jmp     6b
7:      mov     al, ' '
8:      or      dh, dh
        jz      9f
        push    di
        mov     cl, dl
        xor     ch, ch
        rep     stosw
        pop     di
        add     di, bp
        dec     dh
        jmp     8b
9:      pop     bp
        pop     ds
        ret

v_read_ca:
        call    in_gfx
        jc      g_read
        call    cursor_di
        mov     ax, es:[di]
        mov     [bp+16], ax
        ret

v_write_ca:
        call    in_gfx
        jc      g_write
        mov     ah, bl
        push    ax
        call    cursor_di
        pop     ax
        rep     stosw
        ret

v_write_c:
        call    in_gfx
        jc      g_write
        push    ax
        call    cursor_di
        pop     ax
        jcxz    2f
1:      stosb
        inc     di
        loop    1b
2:      ret

# AH=0E: teletype
v_tty:
        mov     bl, [VPAGE]
        xor     bh, bh
        shl     bx, 1
        mov     dx, [bx+VCURPOS]
        cmp     al, 0x0D
        je      3f
        cmp     al, 0x0A
        je      2f
        cmp     al, 0x08
        je      4f
        cmp     al, 0x07
        je      6f
        call    in_gfx
        jnc     7f
        push    bx
        push    dx
        mov     bl, [bp+14]             # grafisch: voorgrondkleur uit BL
        mov     cx, 1
        call    g_write
        pop     dx
        pop     bx
        jmp     8f
7:      push    ax
        call    vid_seg_es
        call    calc_offset
        pop     ax
        mov     es:[di], al
8:      inc     dl
        cmp     dl, [VCOLS]
        jb      5f
        xor     dl, dl
2:      inc     dh
        cmp     dh, 25
        jb      5f
        mov     dh, 24
        push    bx
        push    dx
        mov     ax, 0x0601
        mov     bh, 0x07
        call    in_gfx
        jnc     9f
        xor     bh, bh                  # grafisch: wissen met kleur 0
9:      xor     cx, cx
        mov     dh, 24
        mov     dl, [VCOLS]
        dec     dl
        call    v_scroll
        pop     dx
        pop     bx
        jmp     5f
3:      xor     dl, dl
        jmp     5f
4:      or      dl, dl
        jz      5f
        dec     dl
        jmp     5f
6:      mov     cx, 4
        jmp     beep
5:      mov     [bx+VCURPOS], dx
        jmp     update_cursor

#--- INT 13h: reset, seek, DMA, lees/schrijf/formatteer -----------------------
fdc_reset:
        push    ax
        push    cx
        push    dx
        cli
        mov     al, [MOTOR_ST]
        and     al, 0x0F
        mov     cl, 4
        shl     al, cl
        or      al, 0x08
        mov     dx, 0x3F2
        out     dx, al
        mov     cx, 20
1:      loop    1b
        or      al, 0x04
        out     dx, al
        mov     byte ptr [SEEK_ST], 0
        sti
        call    wait_irq
        jc      3f
        mov     cx, 4
2:      call    sense_int
        jc      3f
        loop    2b
        mov     al, 0x03
        call    fdc_out
        mov     al, 0
        call    get_parm
        call    fdc_out
        mov     al, 1
        call    get_parm
        call    fdc_out
        jc      3f
        mov     byte ptr [DISK_ST], 0
        jmp     4f
3:      mov     byte ptr [DISK_ST], 0x20
4:      pop     dx
        pop     cx
        pop     ax
        ret

recal:
        mov     al, 0x07
        call    fdc_out
        jc      1f
        mov     al, dl
        call    fdc_out
        jc      1f
        call    wait_irq
        jc      1f
        call    sense_int
1:      ret

seek:
        push    cx
        mov     cl, dl
        mov     al, 1
        shl     al, cl
        pop     cx
        test    [SEEK_ST], al
        jnz     2f
        or      [SEEK_ST], al
        call    recal
        jc      9f
        test    byte ptr [FDC_RES], 0x10
        jz      2f
        call    recal
        jc      9f
2:      mov     al, 0x0F
        call    fdc_out
        jc      9f
        call    out_hdus
        jc      9f
        mov     al, ch
        call    fdc_out
        jc      9f
        call    wait_irq
        jc      9f
        call    sense_int
        jc      9f
        mov     al, [FDC_RES]
        and     al, 0xE0
        cmp     al, 0x20
        jne     8f
        cmp     [FDC_RES+1], ch
        jne     8f
        clc
        ret
8:      mov     byte ptr [DISK_ST], 0x40
        stc
9:      ret

# out_hdus: stuur (kop<<2 | station) naar FDC
out_hdus:
        mov     al, dh
        and     al, 1
        shl     al, 1
        shl     al, 1
        or      al, dl
        jmp     fdc_out

# dma_setup: DMA kanaal 2 voor ES:BX, BP = functie/aantal
dma_setup:
        push    ax
        push    bx
        push    cx
        mov     ax, bp
        mov     al, 0x46                # lezen: FDC -> geheugen
        cmp     ah, 4
        jne     1f
        mov     al, 0x42                # verify
1:      cmp     ah, 3
        jb      2f
        cmp     ah, 4
        je      2f
        mov     al, 0x4A                # schrijven/formatteren: geheugen -> FDC
2:      cli
        out     0x0C, al
        out     0x0B, al
        mov     ax, es
        mov     cl, 4
        rol     ax, cl
        mov     ch, al
        and     al, 0xF0
        add     ax, bx
        jnc     3f
        inc     ch
3:      push    ax
        out     0x04, al
        mov     al, ah
        out     0x04, al
        mov     al, ch
        and     al, 0x0F
        out     0x81, al
        mov     ax, bp
        cmp     ah, 5
        jne     6f
        mov     al, 4                   # formatteren: 4 bytes per sector
        call    get_parm
        xor     ah, ah
        shl     ax, 1
        shl     ax, 1
        jmp     7f
6:      mov     ah, al
        xor     al, al
        shl     ax, 1
7:      dec     ax
        out     0x05, al
        xchg    al, ah
        out     0x05, al
        xchg    al, ah
        sti
        pop     cx
        add     cx, ax
        jc      4f
        mov     al, 0x02
        out     0x0A, al
        clc
        jmp     5f
4:      mov     byte ptr [DISK_ST], 0x09
        stc
5:      pop     cx
        pop     bx
        pop     ax
        ret

# fdc_rw: READ/WRITE/FORMAT naar FDC sturen en resultaat beoordelen
fdc_rw:
        mov     ax, bp
        cmp     ah, 5
        je      f_format
        mov     al, 0xE6                # READ DATA (MT, MFM, SK)
        cmp     ah, 3
        jne     1f
        mov     al, 0xC5                # WRITE DATA (MT, MFM)
1:      call    fdc_out
        jc      9f
        call    out_hdus
        jc      9f
        mov     al, ch
        call    fdc_out
        jc      9f
        mov     al, dh
        call    fdc_out
        jc      9f
        mov     al, cl
        call    fdc_out
        jc      9f
        mov     al, 3                   # N, EOT, GPL, DTL
2:      push    ax
        call    get_parm
        call    fdc_out
        pop     ax
        jc      9f
        inc     al
        cmp     al, 7
        jb      2b
fdc_finish:
        call    wait_irq
        jc      9f
        call    fdc_results
        jc      9f
        mov     al, [FDC_RES]
        and     al, 0xC0
        jnz     3f
        clc
        ret
3:      mov     al, [FDC_RES+1]
        mov     ah, 0x04
        test    al, 0x80
        jnz     4f
        mov     ah, 0x10
        test    al, 0x20
        jnz     4f
        mov     ah, 0x08
        test    al, 0x10
        jnz     4f
        mov     ah, 0x04
        test    al, 0x04
        jnz     4f
        mov     ah, 0x03
        test    al, 0x02
        jnz     4f
        mov     ah, 0x02
        test    al, 0x01
        jnz     4f
        mov     ah, 0x20
4:      mov     [DISK_ST], ah
        stc
9:      ret

f_format:                               # FORMAT TRACK: N, SC, GPL, vulbyte
        mov     al, 0x4D
        call    fdc_out
        jc      9b
        call    out_hdus
        jc      9b
        mov     al, 3
        call    get_parm
        call    fdc_out
        mov     al, 4
        call    get_parm
        call    fdc_out
        mov     al, 7
        call    get_parm
        call    fdc_out
        mov     al, 8
        call    get_parm
        call    fdc_out
        jc      9b
        jmp     fdc_finish

#--- INT 14h: seriële poort (8250) -------------------------------------------
#   DX = poort 0-3. AH=00 init (AL=parameters), 01 zenden, 02 ontvangen, 03 status
int14_body:
        sti
        push    bx
        push    cx
        push    dx
        push    di
        push    ds
        mov     di, BDA
        mov     ds, di
        mov     di, dx
        and     di, 3
        mov     bl, [di+COM_TMO]
        shl     di, 1
        mov     dx, [di+COM_BASE]
        or      dx, dx
        jz      s_tmo
        or      ah, ah
        jz      s_init
        cmp     ah, 1
        je      s_send
        cmp     ah, 2
        je      s_recv
        cmp     ah, 3
        je      s_stat
        jmp     s_ret
s_init:
        mov     ch, al                  # parameters bewaren
        add     dx, 3
        mov     al, 0x80                # DLAB aan
        out     dx, al
        mov     al, ch
        mov     cl, 4
        shr     al, cl
        and     ax, 0x000E              # (bits 7-5) * 2
        mov     di, ax
        mov     ax, cs:[di+baud_table]
        sub     dx, 3
        out     dx, al                  # deler laag
        inc     dx
        mov     al, ah
        out     dx, al                  # deler hoog
        add     dx, 2
        mov     al, ch
        and     al, 0x1F                # woordlengte, stopbits, pariteit
        out     dx, al
        sub     dx, 2
        xor     al, al
        out     dx, al                  # IER: geen interrupts
        dec     dx
        jmp     s_stat
s_send:
        mov     cl, al
        add     dx, 4
        mov     al, 0x03                # DTR + RTS
        out     dx, al
        add     dx, 2
        mov     bh, 0x30                # DSR + CTS
        call    s_wait
        jc      s_tmo2
        dec     dx
        mov     bh, 0x20                # THR leeg
        call    s_wait
        jc      s_tmo2
        sub     dx, 5
        mov     al, cl
        out     dx, al
        add     dx, 5
        in      al, dx
        mov     ah, al
        mov     al, cl
        jmp     s_ret
s_recv:
        add     dx, 4
        mov     al, 0x01                # DTR
        out     dx, al
        add     dx, 2
        mov     bh, 0x20                # DSR
        call    s_wait
        jc      s_tmo
        dec     dx
        mov     bh, 0x01                # data klaar
        call    s_wait
        jc      s_tmo
        in      al, dx
        and     al, 0x1E
        mov     ah, al
        sub     dx, 5
        in      al, dx
        jmp     s_ret
s_stat:
        add     dx, 5
        in      al, dx
        mov     ah, al
        inc     dx
        in      al, dx
        jmp     s_ret
s_tmo2: mov     al, cl
s_tmo:  or      ah, 0x80
s_ret:  pop     ds
        pop     di
        pop     dx
        pop     cx
        pop     bx
        iret

# s_wait: wacht tot (poort DX AND BH) == BH, time-out BL * 65536 pogingen
s_wait:
        push    cx
        push    si
        mov     si, bx
        and     si, 0xFF
        jnz     1f
        inc     si
1:      xor     cx, cx
2:      in      al, dx
        and     al, bh
        cmp     al, bh
        je      3f
        loop    2b
        dec     si
        jnz     1b
        stc
        jmp     4f
3:      clc
4:      pop     si
        pop     cx
        ret

#--- INT 09h: toetsenbord (IRQ1), scancode set 1 -----------------------------
int09_body:
        sti
        push    ax
        push    bx
        push    cx
        push    dx
        push    si
        push    ds
        cld
        mov     ax, BDA
        mov     ds, ax
        in      al, 0x60
        mov     ah, al
        call    kbd_ack
        mov     al, ah                  # AL = scancode
        or      al, al
        jz      k_eoi
        cmp     al, 0xFF                # overrun van toetsenbord
        je      k_full
        mov     bl, al
        and     bl, 0x7F                # BL = toets zonder break-bit
        xor     bh, bh
        mov     ch, [KB_FLAG]           # CH = shift-status

        mov     cl, KF_LSHIFT           # shift-toetsen
        cmp     bl, 0x2A
        je      k_shiftkey
        mov     cl, KF_RSHIFT
        cmp     bl, 0x36
        je      k_shiftkey
        mov     cl, KF_CTRL
        cmp     bl, 0x1D
        je      k_shiftkey
        mov     cl, KF_ALT
        cmp     bl, 0x38
        je      k_shiftkey
        mov     cl, KF_CAPS             # toggle-toetsen
        cmp     bl, 0x3A
        je      k_toggle
        mov     cl, KF_NUM
        cmp     bl, 0x45
        je      k_numkey
        mov     cl, KF_SCROLL
        cmp     bl, 0x46
        je      k_scrollkey
        mov     cl, KF_INS
        cmp     bl, 0x52
        je      k_inskey
        test    al, 0x80                # overige break-codes negeren
        jnz     k_eoi
        jmp     k_make

k_shiftkey:
        test    al, 0x80
        jnz     1f
        or      [KB_FLAG], cl
        jmp     k_eoi
1:      not     cl
        and     [KB_FLAG], cl
        cmp     bl, 0x38                # Alt los: Alt+numeriek afronden
        jne     k_eoi
        xor     ax, ax
        xchg    al, [ALT_INPUT]
        or      al, al
        jz      k_eoi
        jmp     k_store

k_numkey:
        test    al, 0x80
        jnz     k_toggle
        test    ch, KF_CTRL
        jnz     k_pause
        jmp     k_toggle

k_scrollkey:
        test    al, 0x80
        jnz     k_toggle
        test    ch, KF_CTRL
        jnz     k_break
        jmp     k_toggle

k_inskey:                               # Ins is alleen Ins als cursortoets
        test    al, 0x80
        jnz     k_toggle
        test    ch, KF_ALT
        jnz     k_make
        call    k_digitmode
        jnz     k_make

# k_toggle: CL = bit (zelfde positie in KB_FLAG en KB_FLAG1)
k_toggle:
        test    al, 0x80
        jz      1f
        not     cl
        and     [KB_FLAG1], cl          # losgelaten
        jmp     k_eoi
1:      test    [KB_FLAG1], cl          # herhaling terwijl ingedrukt?
        jnz     k_eoi
        or      [KB_FLAG1], cl
        xor     [KB_FLAG], cl
        cmp     cl, KF_INS
        jne     k_eoi
        mov     ax, 0x5200
        jmp     k_store

# k_digitmode: NZ als numeriek blok cijfers geeft (NumLock XOR Shift)
k_digitmode:
        push    ax
        mov     al, ch
        test    al, KF_LSHIFT | KF_RSHIFT
        jz      1f
        xor     al, KF_NUM
1:      test    al, KF_NUM
        pop     ax
        ret

k_make:
        test    byte ptr [KB_FLAG1], KF1_HOLD
        jz      1f
        and     byte ptr [KB_FLAG1], 0xFF - KF1_HOLD   # pauze opheffen
        jmp     k_eoi
1:      test    ch, KF_ALT
        jnz     k_alt
        test    ch, KF_CTRL
        jnz     k_ctrl
        cmp     bl, 0x3B
        jb      k_plain
        cmp     bl, 0x44
        ja      k_pad
        mov     ah, bl                  # F1-F10 (Shift: 54h-5Dh)
        test    ch, KF_LSHIFT | KF_RSHIFT
        jz      2f
        add     ah, 0x19
2:      xor     al, al
        jmp     k_store

k_pad:
        cmp     bl, 0x53
        ja      k_eoi
        cmp     bl, 0x4A
        je      k_plain
        cmp     bl, 0x4E
        je      k_plain
        mov     ah, bl
        call    k_digitmode
        jz      3f
        mov     al, cs:[bx+kb_shift]    # cijfer of punt
        jmp     k_store
3:      cmp     bl, 0x4C                # '5' zonder NumLock: niets
        je      k_eoi
        xor     al, al
        jmp     k_store

k_plain:
        cmp     bl, 0x37                # Shift-PrtSc
        jne     4f
        test    ch, KF_LSHIFT | KF_RSHIFT
        jnz     k_prtsc
4:      mov     si, offset kb_normal
        test    ch, KF_LSHIFT | KF_RSHIFT
        jz      5f
        mov     si, offset kb_shift
5:      mov     al, cs:[bx+si]
        test    ch, KF_CAPS
        jz      6f
        mov     ah, al                  # CapsLock: alleen letters omdraaien
        or      ah, 0x20
        cmp     ah, 'a'
        jb      6f
        cmp     ah, 'z'
        ja      6f
        xor     al, 0x20
6:      mov     ah, bl
        jmp     k_store

k_alt:
        test    ch, KF_CTRL
        jz      1f
        cmp     bl, 0x53                # Ctrl-Alt-Del
        je      k_reboot
1:      cmp     bl, 0x47                # Alt + numeriek blok
        jb      2f
        cmp     bl, 0x52
        ja      k_eoi
        mov     al, cs:[bx+kb_shift]
        sub     al, '0'
        cmp     al, 9
        ja      k_eoi
        mov     cl, al
        mov     al, [ALT_INPUT]
        mov     ah, 10
        mul     ah
        add     al, cl
        mov     [ALT_INPUT], al
        jmp     k_eoi
2:      cmp     bl, 0x39                # Alt-spatie
        jne     3f
        mov     ax, 0x3920
        jmp     k_store
3:      test    ch, KF_CTRL
        jnz     k_eoi
        cmp     bl, 0x02
        jb      k_eoi
        cmp     bl, 0x0D
        ja      4f
        mov     ah, bl                  # Alt-1..= -> 78h-83h
        add     ah, 0x76
        xor     al, al
        jmp     k_store
4:      cmp     bl, 0x3B
        jb      5f
        cmp     bl, 0x44
        ja      k_eoi
        mov     ah, bl                  # Alt-F1..F10 -> 68h-71h
        add     ah, 0x2D
        xor     al, al
        jmp     k_store
5:      mov     al, cs:[bx+kb_normal]   # Alt-letter -> 00, scancode
        cmp     al, 'a'
        jb      k_eoi
        cmp     al, 'z'
        ja      k_eoi
        xor     al, al
        mov     ah, bl
        jmp     k_store

k_ctrl:
        cmp     bl, 0x3B
        jb      1f
        cmp     bl, 0x44
        ja      1f
        mov     ah, bl                  # Ctrl-F1..F10 -> 5Eh-67h
        add     ah, 0x23
        xor     al, al
        jmp     k_store
1:      mov     si, offset kb_ctrl_scan
        call    k_lookup
        jc      2f
        mov     ah, al
        xor     al, al
        jmp     k_store
2:      mov     si, offset kb_ctrl_tab
        call    k_lookup
        jc      3f
        mov     ah, bl
        jmp     k_store
3:      cmp     bl, 0x47
        jae     k_eoi
        mov     al, cs:[bx+kb_normal]   # Ctrl-letter -> 01h-1Ah
        cmp     al, 'a'
        jb      k_eoi
        cmp     al, 'z'
        ja      k_eoi
        and     al, 0x1F
        mov     ah, bl
        jmp     k_store

# k_lookup: zoek BL in paren-tabel CS:SI -> AL = waarde, CF=1 niet gevonden
k_lookup:
        mov     al, cs:[si]
        or      al, al
        jz      2f
        cmp     al, bl
        je      1f
        add     si, 2
        jmp     k_lookup
1:      mov     al, cs:[si+1]
        clc
        ret
2:      stc
        ret

# k_store: AX in toetsenbordbuffer
k_store:
        mov     bx, [KB_TAIL]
        mov     si, bx
        add     bx, 2
        cmp     bx, [KB_END]
        jb      1f
        mov     bx, [KB_START]
1:      cmp     bx, [KB_HEAD]
        je      k_full
        mov     [si], ax
        mov     [KB_TAIL], bx
        jmp     k_eoi

k_full:                                 # buffer vol: kort klikje
        in      al, 0x61
        mov     ah, al
        and     al, 0xFC
        mov     cx, 64
1:      xor     al, 0x02
        out     0x61, al
        push    cx
        mov     cx, 60
2:      loop    2b
        pop     cx
        loop    1b
        mov     al, ah
        out     0x61, al

k_eoi:  cli
        mov     al, 0x20
        out     0x20, al
k_exit: pop     ds
        pop     si
        pop     dx
        pop     cx
        pop     bx
        pop     ax
        iret

k_reboot:
        mov     word ptr [RESET_FLAG], 0x1234
        mov     al, 0x20
        out     0x20, al
        .byte   0xEA                    # jmp far F000:E05B
        .word   reset_entry, 0xF000

k_break:                                # Ctrl-Break
        mov     ax, [KB_START]
        mov     [KB_HEAD], ax
        mov     [KB_TAIL], ax
        mov     byte ptr [BREAK_FLAG], 0x80
        int     0x1B
        xor     ax, ax
        jmp     k_store

k_pause:                                # Ctrl-NumLock: wacht op volgende toets
        or      byte ptr [KB_FLAG1], KF1_HOLD
        mov     al, 0x20
        out     0x20, al
        sti
1:      test    byte ptr [KB_FLAG1], KF1_HOLD
        jnz     1b
        jmp     k_exit

k_prtsc:
        mov     al, 0x20
        out     0x20, al
        int     0x05
        jmp     k_exit

#=============================================================================
AT 0xF841                               # vaste entry: INT 12h geheugengrootte
int12:
        push    ds
        mov     ax, BDA
        mov     ds, ax
        mov     ax, [MEMSIZE]
        pop     ds
        iret

AT 0xF84D                               # vaste entry: INT 11h equipment
int11:
        push    ds
        mov     ax, BDA
        mov     ds, ax
        mov     ax, [EQUIP]
        pop     ds
        iret

AT 0xF859                               # vaste entry: INT 15h (cassette)
int15:
        stc
        mov     ah, 0x86
        retf    2

#--- Scancode-tabellen (set 1, XT 83 toetsen), index = scancode 00h-53h -----
kb_normal:
        .byte   0, 0x1B
        .ascii  "1234567890-="
        .byte   0x08, 0x09
        .ascii  "qwertyuiop[]"
        .byte   0x0D, 0
        .ascii  "asdfghjkl;'`"
        .byte   0
        .ascii  "\\zxcvbnm,./"
        .byte   0
        .ascii  "*"
        .byte   0
        .ascii  " "
        .byte   0                                   # 3A caps
        .byte   0,0,0,0,0,0,0,0,0,0                 # 3B-44 F1-F10
        .byte   0, 0                                # 45 num, 46 scroll
        .byte   0,0,0
        .ascii  "-"
        .byte   0,0,0
        .ascii  "+"
        .byte   0,0,0,0,0                           # 4F-53

kb_shift:
        .byte   0, 0x1B
        .ascii  "!@#$%^&*()_+"
        .byte   0x08, 0                             # Shift-Tab -> 0F00
        .ascii  "QWERTYUIOP{}"
        .byte   0x0D, 0
        .ascii  "ASDFGHJKL:\"~"
        .byte   0
        .ascii  "|ZXCVBNM<>?"
        .byte   0
        .ascii  "*"
        .byte   0
        .ascii  " "
        .byte   0
        .byte   0,0,0,0,0,0,0,0,0,0
        .byte   0, 0
        .ascii  "789-456+1230."                     # 47-53 numeriek

# Ctrl-combinaties anders dan letters: scancode, ASCII
kb_ctrl_tab:
        .byte   0x01,0x1B, 0x07,0x1E, 0x0C,0x1F, 0x0E,0x7F, 0x1A,0x1B
        .byte   0x1B,0x1D, 0x1C,0x0A, 0x2B,0x1C, 0x39,0x20, 0
# Ctrl + cursortoetsen / overig: scancode, nieuwe scancode (ASCII 0)
kb_ctrl_scan:
        .byte   0x03,0x03, 0x37,0x72, 0x47,0x77, 0x49,0x84, 0x4B,0x73
        .byte   0x4D,0x74, 0x4F,0x75, 0x51,0x76, 0

#--- INT 17h: printer ---------------------------------------------------------
#   DX = printer 0-2. AH=00 teken AL, 01 init, 02 status
int17_body:
        sti
        push    bx
        push    cx
        push    dx
        push    si
        push    ds
        mov     si, BDA
        mov     ds, si
        mov     si, dx
        and     si, 3
        mov     bl, [si+LPT_TMO]
        shl     si, 1
        mov     dx, [si+LPT_BASE]
        or      dx, dx
        jz      p_ret
        mov     bh, al                  # teken bewaren
        or      ah, ah
        jz      p_print
        cmp     ah, 1
        je      p_init
        cmp     ah, 2
        jne     p_ret
        inc     dx
        jmp     p_status
p_print:
        out     dx, al
        inc     dx                      # statuspoort
        call    p_wait
        jc      p_tmo
        inc     dx                      # besturingspoort
        mov     al, 0x0D                # strobe
        out     dx, al
        mov     al, 0x0C
        out     dx, al
        dec     dx
        jmp     p_status
p_init:
        add     dx, 2
        mov     al, 0x08                # INIT laag
        out     dx, al
        mov     cx, 1000
1:      loop    1b
        mov     al, 0x0C
        out     dx, al
        dec     dx
        jmp     p_status
p_tmo:  call    p_status_ah
        or      ah, 0x01
        jmp     p_done
p_status:
        call    p_status_ah
p_done: mov     al, bh
p_ret:  pop     ds
        pop     si
        pop     dx
        pop     cx
        pop     bx
        iret

p_status_ah:                            # DX = statuspoort -> AH (bits 3,6 omgekeerd)
        in      al, dx
        and     al, 0xF8
        xor     al, 0x48
        mov     ah, al
        ret

p_wait:                                 # wacht op niet-bezig, time-out BL
        mov     si, bx
        and     si, 0xFF
        jnz     1f
        inc     si
1:      xor     cx, cx
2:      in      al, dx
        test    al, 0x80
        jnz     3f
        loop    2b
        dec     si
        jnz     1b
        stc
        ret
3:      clc
        ret

#--- INT 10h: grafische hulpfuncties ----------------------------------------
# in_gfx: CF=1 in grafische mode (4, 5, 6); registers blijven intact
in_gfx:
        cmp     byte ptr [VMODE], 7
        je      1f
        cmp     byte ptr [VMODE], 4
        cmc
        ret
1:      clc
        ret

# AH=04: lichtpen - niet aanwezig
v_lpen:
        mov     byte ptr [bp+17], 0
        ret

# AH=0B: palet. BH=0: BL = achtergrond/rand (0-1Fh); BH=1: BL = palet 0/1
v_palette:
        mov     al, [VPAL]
        or      bh, bh
        jnz     1f
        and     al, 0xE0
        and     bl, 0x1F
        or      al, bl
        jmp     2f
1:      and     al, 0xDF
        test    bl, 1
        jz      2f
        or      al, 0x20
2:      mov     [VPAL], al
        cmp     byte ptr [VMODE], 7
        je      3f
        mov     dx, 0x3D9
        out     dx, al
3:      ret

# pix_addr: DX = rij, CX = kolom -> ES:DI, CL = schuif, AH = masker
pix_addr:
        call    vid_seg_es
        mov     al, dl
        shr     al, 1
        mov     bl, 80
        mul     bl
        test    dl, 1
        jz      1f
        add     ax, 0x2000
1:      mov     di, ax
        mov     bx, cx
        mov     ax, cx
        mov     cl, 2
        cmp     byte ptr [VMODE], 6
        jne     2f
        inc     cl
2:      shr     ax, cl
        add     di, ax
        mov     cl, bl
        cmp     byte ptr [VMODE], 6
        jne     3f
        and     cl, 7
        xor     cl, 7
        mov     ah, 1
        ret
3:      and     cl, 3
        xor     cl, 3
        shl     cl, 1
        mov     ah, 3
        ret

# AH=0C: pixel schrijven (AL = kleur, bit7 = XOR)
v_wpixel:
        call    in_gfx
        jnc     2f
        push    ax
        call    pix_addr
        pop     bx
        mov     al, bl
        and     al, ah
        shl     al, cl
        shl     ah, cl
        test    bl, 0x80
        jnz     1f
        not     ah
        and     es:[di], ah
        or      es:[di], al
        ret
1:      xor     es:[di], al
2:      ret

# AH=0D: pixel lezen -> AL
v_rpixel:
        call    in_gfx
        jnc     1f
        call    pix_addr
        mov     al, es:[di]
        shr     al, cl
        and     al, ah
        mov     [bp+16], al
1:      ret

#=============================================================================
AT 0xFA6E                               # vaste entry: 8x8-font (CGA grafisch)
font_8x8:                               # eigen ontwerp, zie font8x8.txt
        .include "font8x8.inc"

#=============================================================================
AT 0xFE6E                               # vaste entry: INT 1Ah tijd
int1a:
        sti
        push    ds
        push    ax
        mov     ax, BDA
        mov     ds, ax
        pop     ax
        cli
        or      ah, ah
        jnz     1f
        mov     al, [TIMER_OFL]
        mov     byte ptr [TIMER_OFL], 0
        mov     cx, [TIMER_HI]
        mov     dx, [TIMER_LO]
        jmp     2f
1:      cmp     ah, 1
        jne     2f
        mov     [TIMER_LO], dx
        mov     [TIMER_HI], cx
        mov     byte ptr [TIMER_OFL], 0
2:      sti
        pop     ds
        iret

AT 0xFEA5                               # vaste entry: INT 08h (IRQ0, timer)
int08:
        jmp     int08_body

# INT 18h: geen ROM BASIC -> melding en opnieuw proberen
int18:
        call    bbc_present             # BBC BASIC-ROM in de BASIC-socket?
        jne     1f
        .byte   0xEA                    # jmp far F600:0000
        .word   0x0000, 0xF600
1:      cli
        mov     ax, 0x0030
        mov     ss, ax
        mov     sp, 0x0100
        sti
        mov     si, offset msg_noboot
        call    print_str
        mov     ax, BDA
        mov     ds, ax
        mov     cx, 55
        call    wait_ticks
        int     0x19


AT 0xFEF3                               # vaste entry: vectortabel INT 08-1F
vector_table:
        .word   int08, int09, dummy_int, dummy_int      # 08-0B
        .word   dummy_int, dummy_int, int0e, dummy_int  # 0C-0F
        .word   int10, int11, int12, int13              # 10-13
        .word   int14, int15, int16, int17              # 14-17
        .word   int18, int19, int1a, iret_only          # 18-1B
        .word   iret_only, video_params, disk_params, 0 # 1C-1F

AT 0xFF23                               # vaste entry: onverwachte interrupt
dummy_int:
        push    ax
        push    ds
        mov     ax, BDA
        mov     ds, ax
        mov     al, 0x0B
        out     0x20, al
        nop
        in      al, 0x20
        mov     [LAST_IRQ], al
        or      al, al
        jz      1f
        mov     al, 0x20
        out     0x20, al
1:      pop     ds
        pop     ax
        iret

AT 0xFF53                               # vaste entry: IRET
iret_only:
        iret

AT 0xFF54                               # vaste entry: INT 05h print screen
int05:
        jmp     int05_body

# INT 08h-afhandeling (entry op FEA5)
int08_body:
        push    ax
        push    dx
        push    ds
        mov     ax, BDA
        mov     ds, ax
        inc     word ptr [TIMER_LO]
        jnz     1f
        inc     word ptr [TIMER_HI]
1:      cmp     word ptr [TIMER_HI], 0x18   # 24 uur = 1800B0h ticks
        jne     2f
        cmp     word ptr [TIMER_LO], 0xB0
        jne     2f
        xor     ax, ax
        mov     [TIMER_LO], ax
        mov     [TIMER_HI], ax
        mov     byte ptr [TIMER_OFL], 1
2:      cmp     byte ptr [MOTOR_CNT], 0     # diskettemotor-timeout
        je      3f
        dec     byte ptr [MOTOR_CNT]
        jnz     3f
        and     byte ptr [MOTOR_ST], 0xF0
        mov     al, 0x0C
        mov     dx, 0x3F2
        out     dx, al
3:      int     0x1C
        mov     al, 0x20
        out     0x20, al
        pop     ds
        pop     dx
        pop     ax
        iret



#=============================================================================
AT 0xFFF0                               # reset-vector: CPU start hier
        .byte   0xEA
        .word   reset_entry, 0xF000
        .ascii  "01/01/26"
        .byte   0x00
        .byte   0xFE                    # modelbyte: PC/XT
        .byte   0x00                    # checksum (door fixsum.py)
