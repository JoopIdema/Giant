#!/usr/bin/env python3
"""font8x8.txt -> font8x8.inc (1024 bytes, tekens 00h-7Fh) en optioneel een PNG-preview."""
import sys
glyphs = [[0]*8 for _ in range(128)]
for n, line in enumerate(open("font8x8.txt"), 1):
    line = line.split("#", 1)[0] if line.lstrip().startswith("#") else line
    line = line.strip()
    if not line:
        continue
    code, rows = line.split(":", 1)
    rows = rows.split()
    c = int(code, 16)
    if c > 0x7F or len(rows) != 8 or any(len(r) != 8 or set(r) - set(".#") for r in rows):
        sys.exit(f"font8x8.txt regel {n}: ongeldige glyph {code}")
    glyphs[c] = [int(r.replace("#", "1").replace(".", "0"), 2) for r in rows]
with open("font8x8.inc", "w") as f:
    f.write("# gegenereerd door mkfont.py uit font8x8.txt - niet met de hand bewerken\n")
    for c, g in enumerate(glyphs):
        f.write("        .byte   " + ",".join(f"0x{b:02X}" for b in g) + f"   # {c:02X}\n")
if len(sys.argv) > 1:
    from PIL import Image
    im = Image.new("1", (16*9, 8*9), 0)
    for c, g in enumerate(glyphs):
        for y, b in enumerate(g):
            for x in range(8):
                if b & (0x80 >> x):
                    im.putpixel(((c % 16)*9 + x, (c // 16)*9 + y), 1)
    im.resize((im.width*4, im.height*4)).save(sys.argv[1])
print("font8x8.inc gemaakt")
